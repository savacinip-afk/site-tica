<?php
if (!defined('ABSPATH')) exit;
class Otica_Elementor_Content_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'otica-conteudo'; }
    public function get_title() { return 'Cadastros da rede'; }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_categories() { return ['otica-rede']; }
    protected function register_controls() {
        $this->start_controls_section('otica_content', ['label' => 'Conteúdo da rede']);
        $options = []; foreach (otica_elementor_sections() as $key => $section) $options[$key] = $section[0];
        $this->add_control('conteudo', ['label' => 'Seção exibida', 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $options, 'default' => 'unidades']);
        $html = '<p>Arraste este widget ou seu contêiner para mudar a ordem. Para trocar fotos, logos, nomes e contatos, abra o cadastro correspondente:</p><ul>';
        foreach (otica_elementor_sections() as $section) $html .= '<li><a target="_blank" rel="noopener" href="' . esc_url(admin_url($section[2])) . '">' . esc_html($section[0]) . '</a></li>';
        $this->add_control('otica_admin_help', ['type' => \Elementor\Controls_Manager::RAW_HTML, 'raw' => $html . '</ul><p>Use Visualizar para testar o formulário e os efeitos. Os dados não são duplicados.</p>', 'content_classes' => 'elementor-panel-alert elementor-panel-alert-info']);
        $this->end_controls_section();
    }
    protected function render() { $sections = otica_elementor_sections(); $key = $this->get_settings_for_display('conteudo'); if (isset($sections[$key])) echo do_shortcode('[' . $sections[$key][1] . ']'); }
}
