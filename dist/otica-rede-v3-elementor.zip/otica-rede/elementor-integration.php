<?php
/** Migração não destrutiva para Elementor gratuito. */
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () { add_theme_support('elementor'); });
add_filter('elementor/fonts/additional_fonts', function ($fonts) { $fonts['Manrope'] = 'system'; $fonts['Barlow Condensed'] = 'system'; return $fonts; });
add_filter('theme_page_templates', function ($templates) { $templates['otica-elementor.php'] = 'Elementor — layout da rede'; return $templates; });
add_filter('template_include', function ($template) {
    if (is_singular('page') && get_page_template_slug(get_queried_object_id()) === 'otica-elementor.php') return __DIR__ . '/otica-elementor.php';
    return $template;
}, 99);
add_action('wp_enqueue_scripts', function () {
    if (is_singular('page') && get_page_template_slug(get_queried_object_id()) === 'otica-elementor.php') wp_enqueue_style('otica-elementor', get_theme_file_uri('assets/elementor.css'), ['otica-site'], '3.0.0');
}, 30);
add_action('elementor/elements/categories_registered', function ($manager) { $manager->add_category('otica-rede', ['title' => 'Rede de Óticas', 'icon' => 'fa fa-eye']); });
add_action('elementor/widgets/register', function ($manager) { require_once __DIR__ . '/elementor-widget.php'; $manager->register(new Otica_Elementor_Content_Widget()); });

function otica_elementor_sections() {
    return [
        'unidades' => ['Unidades', 'otica_unidades', 'edit.php?post_type=unidade'],
        'lojas_completo' => ['Lojas com mapas e contatos', 'otica_unidades completo="sim"', 'edit.php?post_type=unidade'],
        'produtos' => ['Produtos e categorias', 'otica_produtos', 'edit.php?post_type=produto_otica'],
        'relogios' => ['Relógios', 'otica_relogios', 'edit.php?post_type=otica_relogio'],
        'marcas' => ['Carrossel de marcas', 'otica_marcas', 'edit.php?post_type=otica_marca'],
        'convenios' => ['Convênios', 'otica_convenios', 'edit.php?post_type=otica_convenio'],
        'influencers' => ['Influencers', 'otica_influencers', 'edit.php?post_type=otica_influencer'],
        'equipe' => ['Equipe', 'otica_equipe', 'edit.php?post_type=otica_pessoa'],
        'carreiras' => ['Currículos — WhatsApp e e-mail', 'otica_carreiras', 'admin.php?page=otica-carreiras'],
        'agendamento' => ['Formulário de agendamento', 'otica_agendamento', 'edit.php?post_type=unidade'],
        'blog' => ['Artigos do blog', 'otica_blog_elementor', 'edit.php'],
    ];
}
add_shortcode('otica_blog_elementor', function () {
    $page = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
    $query = new WP_Query(['post_type' => 'post', 'posts_per_page' => 6, 'paged' => $page, 'post_status' => 'publish']);
    ob_start(); echo '<div class="otica-blog-grid">';
    while ($query->have_posts()) { $query->the_post(); echo '<article class="otica-blog-card">';
        if (has_post_thumbnail()) echo '<a href="' . esc_url(get_permalink()) . '">' . get_the_post_thumbnail(get_the_ID(), 'large', ['loading' => 'lazy']) . '</a>';
        echo '<h3><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></h3><p>' . esc_html(wp_trim_words(get_the_excerpt(), 27)) . '</p><a href="' . esc_url(get_permalink()) . '">Ler artigo ↗︎</a></article>';
    }
    echo '</div>'; if (!$query->post_count) echo '<p>Em breve, novas dicas sobre visão.</p>';
    if ($query->max_num_pages > 1) echo '<nav class="otica-blog-pagination" aria-label="Páginas de artigos">' . wp_kses_post(paginate_links(['total' => $query->max_num_pages, 'current' => $page])) . '</nav>';
    wp_reset_postdata(); return ob_get_clean();
});

function otica_el_id() { static $id = 0; return str_pad(dechex(++$id), 7, '0', STR_PAD_LEFT); }
function otica_el_widget($type, $settings, $label = '') {
    if (in_array($type, ['heading', 'text-editor', 'button'], true)) {
        $settings += ['typography_typography' => 'custom', 'typography_font_family' => $type === 'heading' ? 'Barlow Condensed' : 'Manrope', 'typography_font_weight' => $type === 'text-editor' ? '400' : '800'];
    }
    if ($type === 'heading') $settings += ['title_color' => '#171719'];
    if ($type === 'text-editor') $settings += ['text_color' => '#171719'];
    if ($label) $settings['_title'] = $label;
    return ['id' => otica_el_id(), 'elType' => 'widget', 'widgetType' => $type, 'settings' => $settings, 'elements' => []];
}
function otica_el_container($children, $classes, $label, $anchor = '') {
    $settings = ['content_width' => 'full', 'css_classes' => $classes, '_title' => $label, 'flex_direction' => 'column'];
    if ($anchor) $settings['_element_id'] = $anchor;
    return ['id' => otica_el_id(), 'elType' => 'container', 'isInner' => false, 'settings' => $settings, 'elements' => $children];
}
function otica_el_label($classes) {
    $labels = ['hero-v2'=>'Banner principal','marquee-strip'=>'Faixa em movimento','products-section'=>'Produtos','watches-section'=>'Relógios','brands-section'=>'Marcas parceiras','agreements-section'=>'Convênios','story-section'=>'Editorial — pessoas','stores-section'=>'Nossas lojas','benefits-section'=>'Diferenciais','influencers-section'=>'Influencers','appointment-section'=>'Agendamento','about-preview-section'=>'Prévia de Sobre nós','closing-section'=>'Chamada final','team-section'=>'Nossa equipe','careers-section'=>'Trabalhe conosco','hero-content'=>'Textos e botões do banner','hero-media'=>'Fotografia principal','hero-editorial-note'=>'Assinatura do banner','section-heading'=>'Título e apresentação','section-inner'=>'Conteúdo da seção','benefit'=>'Benefício','benefits-grid'=>'Quadro de benefícios','story-copy'=>'Texto institucional','story-visual'=>'Foto institucional','about-preview-copy'=>'Texto e botão institucional','about-preview-title'=>'Título institucional'];
    foreach ($labels as $class => $label) if (in_array($class, preg_split('/\s+/', $classes), true)) return $label;
    return 'Grupo de conteúdo';
}
function otica_el_convert($blocks, $context = 'default') {
    $elements = [];
    foreach ($blocks as $block) {
        $name = $block['blockName']; $attrs = $block['attrs'] ?? []; $html = trim($block['innerHTML'] ?? ''); $children = $block['innerBlocks'] ?? [];
        if (!$name && !$html) continue;
        $classes = $attrs['className'] ?? '';
        if (in_array($name, ['core/group', 'core/columns', 'core/column', 'core/buttons'], true)) {
            if ($name === 'core/buttons') $classes .= ' wp-block-buttons otica-elementor-buttons';
            if ($name === 'core/columns') $classes .= ' otica-elementor-columns';
            if ($name === 'core/column') $classes .= ' otica-elementor-column';
            $child_context = $context;
            foreach (['hero-v2', 'story-section', 'watches-section', 'careers-section', 'marquee-strip'] as $dark) if (in_array($dark, preg_split('/\s+/', $classes), true)) $child_context = 'dark';
            if (strpos($classes, 'closing-section') !== false) $child_context = 'closing';
            $elements[] = otica_el_container(otica_el_convert($children, $child_context), trim($classes), $name === 'core/buttons' ? 'Botões' : otica_el_label($classes), $attrs['anchor'] ?? '');
        } elseif ($name === 'core/heading') {
            preg_match('/<h([1-6])\b[^>]*>(.*?)<\/h\1>/is', $html, $m); $title = $m[2] ?? wp_strip_all_tags($html); $tag = 'h' . ($attrs['level'] ?? ($m[1] ?? 2));
            $elements[] = otica_el_widget('heading', ['title' => wp_kses_post($title), 'title_color' => $context === 'default' ? '#171719' : '#ffffff', 'header_size' => $tag, 'size' => 'default', '_css_classes' => trim('otica-editable-heading ' . $classes)], wp_trim_words(wp_strip_all_tags($title), 8));
        } elseif ($name === 'core/paragraph' || $name === 'core/list' || $name === 'core/table' || $name === null || $name === 'core/html') {
            $elements[] = otica_el_widget('text-editor', ['editor' => wp_kses_post($html), 'text_color' => $context === 'default' ? '#171719' : '#ffffff', '_css_classes' => 'otica-editable-text' . (strpos($classes, 'scroll-cue') !== false ? ' otica-scroll-cue-widget' : '')], wp_trim_words(wp_strip_all_tags($html), 7));
        } elseif ($name === 'core/image') {
            $tag = new WP_HTML_Tag_Processor($html); $url = ''; $alt = '';
            while ($tag->next_tag('IMG')) { $url = $tag->get_attribute('src'); $alt = $tag->get_attribute('alt'); break; }
            $elements[] = otica_el_widget('image', ['image' => ['url' => esc_url_raw($url), 'id' => (int) ($attrs['id'] ?? 0), 'alt' => sanitize_text_field($alt)], 'image_size' => 'full', '_css_classes' => trim($classes . ' otica-editable-image')], $classes === 'hero-photo' ? 'Trocar foto principal' : 'Trocar fotografia');
        } elseif ($name === 'core/button') {
            $tag = new WP_HTML_Tag_Processor($html); $url = '';
            while ($tag->next_tag('A')) { $url = $tag->get_attribute('href'); break; }
            preg_match('/<a\b[^>]*>(.*?)<\/a>/is', $html, $m); $text = html_entity_decode(wp_strip_all_tags($m[1] ?? 'Saiba mais'), ENT_QUOTES, 'UTF-8');
            if (strpos($url, '/') === 0 && strpos($url, '//') !== 0) $url = home_url($url);
            $elements[] = otica_el_widget('button', ['text' => $text, 'background_background' => 'classic', 'background_color' => strpos($classes, 'is-style-outline') !== false ? 'rgba(255,255,255,0)' : ($context === 'closing' ? '#ffffff' : '#d71920'), 'button_text_color' => $context === 'closing' ? '#d71920' : '#ffffff', 'link' => ['url' => esc_url_raw($url)], 'size' => 'sm', '_css_classes' => trim($classes . ' otica-editable-button')], $text);
        } elseif ($name === 'core/shortcode') {
            $found = false;
            foreach (otica_elementor_sections() as $key => $section) if (trim($html) === '[' . $section[1] . ']') { $elements[] = otica_el_widget('otica-conteudo', ['conteudo' => $key], $section[0] . ' — cadastro no painel'); $found = true; break; }
            if (!$found) $elements[] = otica_el_widget('shortcode', ['shortcode' => $html], 'Conteúdo dinâmico');
        } elseif ($name === 'core/query') {
            $elements[] = otica_el_widget('otica-conteudo', ['conteudo' => 'blog'], 'Artigos do blog — posts nativos');
        } else {
            // Blocos não reconhecidos continuam editáveis como texto, nunca em um HTML monolítico.
            $elements[] = otica_el_widget('text-editor', ['editor' => wp_kses_post(render_block($block))], 'Conteúdo complementar');
        }
    }
    return $elements;
}

add_action('admin_menu', function () { add_theme_page('Preparar Elementor', 'Preparar Elementor', 'manage_options', 'otica-elementor', 'otica_elementor_admin'); });
function otica_elementor_admin() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Preparar páginas para Elementor gratuito</h1>';
    if (isset($_POST['otica_convert_elementor']) && check_admin_referer('otica_convert_elementor')) {
        $source = absint($_POST['otica_elementor_source'] ?? 0); $result = otica_prepare_elementor($source);
        if (is_wp_error($result)) echo '<div class="notice notice-error"><p>' . esc_html($result->get_error_message()) . '</p></div>';
        else { echo '<div class="notice notice-success otica-elementor-success"><p>Páginas de teste preparadas em rascunho. As originais foram preservadas.</p><ul>'; foreach ($result as $kind => $id) echo '<li><a class="otica-el-' . esc_attr($kind) . '" href="' . esc_url(admin_url('post.php?post=' . $id . '&action=elementor')) . '">Editar ' . esc_html(get_the_title($id)) . ' com Elementor</a> · <a href="' . esc_url(get_preview_post_link($id)) . '" target="_blank" rel="noopener">Visualizar</a></li>'; echo '</ul></div>'; }
    }
    if (!did_action('elementor/loaded')) { echo '<div class="notice notice-warning"><p>Primeiro instale e ative o plugin gratuito <strong>Elementor Website Builder</strong>, do autor Elementor.com, em Plugins → Adicionar plugin. Não é necessário Elementor Pro nem conectar uma conta paga.</p></div></div>'; return; }
    echo '<p>Converte textos, títulos, fotografias, botões e grupos em widgets e contêineres nativos do Elementor. Cria páginas independentes em rascunho; não publica, não troca a página inicial e não sobrescreve suas páginas atuais.</p><p>Os dados das lojas, produtos, marcas, convênios, influencers e funcionários continuam nos cadastros existentes. Seus blocos recebem um widget próprio, com atalhos para o painel. Cabeçalho e rodapé continuam compartilhados pelo tema e podem ser editados em Aparência → Editor, sem Elementor Pro.</p><form method="post">'; wp_nonce_field('otica_convert_elementor');
    $selected = (int) get_option('page_on_front'); if (!$selected) { $latest = get_page_by_path('inicio-final-22'); if ($latest) $selected = $latest->ID; }
    echo '<p><label for="otica-elementor-source"><strong>Qual página inicial deseja adaptar?</strong></label></p>'; wp_dropdown_pages(['name' => 'otica_elementor_source', 'id' => 'otica-elementor-source', 'selected' => $selected, 'post_status' => ['publish', 'draft', 'private', 'pending'], 'show_option_none' => 'Selecione a página final aprovada', 'option_none_value' => 0]);
    submit_button('Preparar páginas de teste para Elementor', 'primary', 'otica_convert_elementor');
    echo '</form><p>Se já tiver preparado estas páginas, o botão abre as mesmas cópias, preservando suas edições no Elementor. Teste o agendamento e as animações em Visualizar. A edição não exige serviços pagos.</p></div>';
}
function otica_prepare_elementor($source_id) {
    if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Permissão insuficiente.');
    if (!did_action('elementor/loaded') || !class_exists(\Elementor\Plugin::class)) return new WP_Error('plugin', 'Ative o plugin gratuito Elementor antes de preparar as páginas.');
    if (version_compare(ELEMENTOR_VERSION, '3.18', '<')) return new WP_Error('version', 'Atualize o Elementor para uma versão atual compatível com seu WordPress.');
    $home = get_post($source_id); if (!$home || $home->post_type !== 'page' || !current_user_can('edit_post', $source_id)) return new WP_Error('source', 'Selecione uma página inicial válida para adaptar.');
    $expansion = get_option('otica_expansion_v21', []);
    $sources = ['home' => $home, 'about' => !empty($expansion['about']) ? get_post($expansion['about']) : get_page_by_path('sobre-nos')];
    foreach (['products' => 'produtos', 'stores' => 'nossas-lojas', 'appointment' => 'agendamento', 'blog' => 'dicas-sobre-visao', 'privacy' => 'politica-de-privacidade'] as $kind => $slug) $sources[$kind] = get_page_by_path($slug);
    $mapping = get_option('otica_elementor_pages', []); if (!is_array($mapping)) $mapping = [];
    foreach ($sources as $kind => $source) {
        if (!$source || $source->post_type !== 'page' || !current_user_can('edit_post', $source->ID)) continue;
        if (!empty($mapping[$kind]) && get_post_status($mapping[$kind]) !== 'trash' && get_post_type($mapping[$kind]) === 'page' && (int) get_post_meta($mapping[$kind], '_otica_elementor_source', true) === $source->ID) continue;
        $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'draft', 'post_title' => $source->post_title . ' — Elementor', 'post_name' => 'elementor-' . $source->post_name, 'post_content' => $source->post_content], true);
        if (is_wp_error($id)) return $id;
        update_post_meta($id, '_wp_page_template', 'otica-elementor.php'); update_post_meta($id, '_otica_elementor_source', $source->ID);
        $existing_data = get_post_meta($source->ID, '_elementor_data', true);
        if (get_post_meta($source->ID, '_elementor_edit_mode', true) === 'builder' && $existing_data) $elements = is_array($existing_data) ? $existing_data : json_decode($existing_data, true);
        else {
            $elements = otica_el_convert(parse_blocks($source->post_content));
            if ($kind !== 'home') array_unshift($elements, otica_el_widget('heading', ['title' => esc_html($source->post_title), 'header_size' => 'h1', 'size' => 'default'], 'Título da página'));
            if ($kind !== 'home') $elements = [otica_el_container($elements, $kind === 'about' ? 'institutional-shell' : 'article-shell', 'Conteúdo da página')];
        }
        update_post_meta($id, '_elementor_edit_mode', 'builder'); update_post_meta($id, '_elementor_template_type', 'wp-page'); update_post_meta($id, '_elementor_version', ELEMENTOR_VERSION);
        $document = \Elementor\Plugin::$instance->documents->get($id);
        if (!$document || !$document->save(['elements' => $elements])) { wp_trash_post($id); return new WP_Error('save', 'O Elementor não conseguiu salvar a cópia. A página original foi preservada.'); }
        update_post_meta($id, '_wp_page_template', 'otica-elementor.php');
        foreach (['_thumbnail_id', '_otica_seo'] as $meta) { $value = get_post_meta($source->ID, $meta, true); if ($value !== '') update_post_meta($id, $meta, $value); }
        $mapping[$kind] = $id; update_option('otica_elementor_pages', $mapping, false);
    }
    \Elementor\Plugin::$instance->files_manager->clear_cache();
    return $mapping;
}

function otica_elementor_links($html) {
    if (stripos($html, '<a') === false) return $html;
    $mapping = get_option('otica_elementor_pages', []); if (!is_array($mapping) || empty($mapping['home'])) return $html;
    $current = get_queried_object_id();
    $preview = in_array($current, array_map('intval', array_values($mapping)), true) && current_user_can('edit_post', $current);
    $live = (int) get_option('page_on_front') === (int) $mapping['home'] && get_post_status($mapping['home']) === 'publish';
    if (!$preview && !$live) return $html;
    $paths = ['home' => '/', 'about' => '/sobre-nos/', 'products' => '/produtos/', 'stores' => '/nossas-lojas/', 'appointment' => '/agendamento/', 'blog' => '/dicas-sobre-visao/', 'privacy' => '/politica-de-privacidade/'];
    $links = []; $source_links = []; $target_ids = array_map('intval', array_values($mapping));
    foreach ($paths as $kind => $path) {
        $id = (int) ($mapping[$kind] ?? 0); if (!$id || get_post_type($id) !== 'page') continue;
        $published = get_post_status($id) === 'publish'; if (!$published && !$preview) continue;
        $target = $published ? get_permalink($id) : get_preview_post_link($id);
        $sources = [home_url($path)]; $source = (int) get_post_meta($id, '_otica_elementor_source', true); if ($source) { $sources[] = get_permalink($source); $source_links[$source] = $target; }
        foreach (array_unique($sources) as $url) if ($url) $links[untrailingslashit($url)] = $target;
    }
    $processor = new WP_HTML_Tag_Processor($html);
    while ($processor->next_tag('A')) {
        $href = $processor->get_attribute('href'); if (!is_string($href) || !$href || $href[0] === '#') continue;
        if (strpos($href, '/') === 0 && strpos($href, '//') !== 0) $href = home_url($href);
        $base = preg_split('/[?#]/', $href, 2)[0]; $key = untrailingslashit($base);
        $query = []; parse_str((string) wp_parse_url($href, PHP_URL_QUERY), $query);
        $page_id = absint($query['page_id'] ?? ($query['preview_id'] ?? 0));
        if ($page_id && in_array($page_id, $target_ids, true)) continue;
        if ($page_id) { if (!isset($source_links[$page_id])) continue; $target = $source_links[$page_id]; }
        else { if (!isset($links[$key])) continue; $target = $links[$key]; }
        if (isset($query['otica_unidade'])) $target = add_query_arg('otica_unidade', absint($query['otica_unidade']), $target);
        $fragment = wp_parse_url($href, PHP_URL_FRAGMENT); if ($fragment) $target .= '#' . rawurlencode($fragment);
        $processor->set_attribute('href', esc_url_raw($target));
    }
    $html = $processor->get_updated_html();
    return $html;
}
add_filter('render_block', 'otica_elementor_links', 25);
add_filter('elementor/widget/render_content', 'otica_elementor_links', 25);
add_filter('the_content', 'otica_elementor_links', 99);

function otica_elementor_preview_document() {
    $id = isset($_GET['elementor-preview']) ? absint($_GET['elementor-preview']) : 0;
    return $id && get_page_template_slug($id) === 'otica-elementor.php';
}
add_action('elementor/preview/enqueue_styles', function () {
    if (otica_elementor_preview_document()) wp_enqueue_style('otica-elementor', get_theme_file_uri('assets/elementor.css'), ['otica-site'], '3.0.0');
});
add_filter('body_class', function ($classes) {
    if (otica_elementor_preview_document()) { $classes[] = 'otica-elementor'; $classes[] = 'wp-block-post-content'; }
    return $classes;
});
