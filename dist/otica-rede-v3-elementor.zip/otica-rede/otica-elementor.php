<?php
/** Template Name: Elementor — layout da rede
 * Template Post Type: page
 */
if (!defined('ABSPATH')) exit;
// Resolve blocos e conteúdo antes de wp_head, para carregar módulos de navegação
// e estilos tanto do tema de blocos quanto dos widgets do Elementor.
$otica_header_html = do_shortcode(do_blocks('<!-- wp:template-part {"slug":"header"} /-->'));
$otica_footer_html = do_shortcode(do_blocks('<!-- wp:template-part {"slug":"footer"} /-->'));
ob_start(); while (have_posts()) { the_post(); the_content(); } $otica_content_html = ob_get_clean();
?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class('otica-elementor-layout'); ?>><?php wp_body_open(); ?>
<div class="wp-site-blocks"><header class="wp-block-template-part"><?php echo $otica_header_html; ?></header><main id="content" class="otica-elementor wp-block-post-content"><?php echo $otica_content_html; ?></main><footer class="wp-block-template-part"><?php echo $otica_footer_html; ?></footer></div>
<?php wp_footer(); ?></body></html>
