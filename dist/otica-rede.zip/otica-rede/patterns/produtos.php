<?php
/**
 * Title: Vitrine de categorias administráveis
 * Slug: otica-rede/produtos
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"align": "full", "className": "section", "layout": {"type": "constrained"}} --><div class="wp-block-group alignfull section" ><!-- wp:paragraph --><p>ENCONTRE SEU ESTILO</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">Um novo jeito de <em>se ver.</em></h2><!-- /wp:heading --><!-- wp:paragraph --><p>Conheça opções para o seu dia a dia. A escolha ideal começa com uma conversa.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[otica_produtos]<!-- /wp:shortcode --></div><!-- /wp:group -->