<?php
/**
 * Title: Formulário de solicitação
 * Slug: otica-rede/agendamento
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"align": "full", "className": "section", "layout": {"type": "constrained"}} --><div class="wp-block-group alignfull section" ><!-- wp:shortcode -->[otica_agendamento]<!-- /wp:shortcode --></div><!-- /wp:group -->