<?php
/**
 * Title: Unidades com agendamento
 * Slug: otica-rede/unidades
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"align": "full", "className": "section", "layout": {"type": "constrained"}} --><div class="wp-block-group alignfull section" ><!-- wp:paragraph --><p>PERTO DE VOCÊ</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">A ótica mais próxima de você!</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Estamos presentes em cinco endereços para cuidar da sua visão com conforto, qualidade e atendimento personalizado.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[otica_unidades]<!-- /wp:shortcode --></div><!-- /wp:group -->