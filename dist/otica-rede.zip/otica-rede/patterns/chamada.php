<?php
/**
 * Title: Chamada comercial editável
 * Slug: otica-rede/chamada
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"align": "full", "className": "section editorial-banner", "layout": {"type": "constrained"}} --><div class="wp-block-group alignfull section editorial-banner" ><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">Seu próximo olhar começa <em>com uma conversa.</em></h2><!-- /wp:heading --><!-- wp:paragraph --><p>Escolha a unidade mais próxima e fale com nossa equipe.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {} --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/nossas-lojas/">Encontre sua loja</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:group -->