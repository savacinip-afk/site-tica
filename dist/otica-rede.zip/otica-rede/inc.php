<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu',function(){add_theme_page('Preparar site','Preparar site','manage_options','otica-setup','otica_setup_page');});
function otica_setup_page(){
 if(!current_user_can('manage_options')) return;
 if(isset($_POST['otica_visual_v2']) && check_admin_referer('otica_visual_v2')){ $new=otica_create_visual_v2();if(is_wp_error($new)){echo '<div class="notice notice-error"><p>'.esc_html($new->get_error_message()).'</p></div>';}else{echo '<div class="notice notice-success"><p>Nova página visual criada em rascunho. Seu conteúdo anterior foi preservado. <a href="'.esc_url(get_edit_post_link($new)).'">Abrir nova página</a></p></div>';}}
 if(isset($_POST['otica_import']) && check_admin_referer('otica_import')) {otica_seed();echo '<div class="notice notice-success"><p>Conteúdo inicial criado em rascunho. Revise as páginas, cadastre os contatos e publique apenas quando estiver pronto.</p></div>';}
 echo '<div class="wrap"><h1>Preparar sua rede de óticas — versão 2.0</h1><p>Cria páginas e artigos em rascunho, cinco unidades e quatro categorias de produtos, todos em rascunho. Não substitui conteúdos existentes, não publica páginas e não altera sua página inicial automaticamente.</p><p>Depois: configure os WhatsApps em Unidades, edite os conteúdos no Gutenberg e escolha Início em Configurações → Leitura. Use o modelo Início na página inicial. No Editor do site, ajuste cabeçalho, navegação, rodapé, cores e logotipo.</p><p>As fotos e a identidade são provisórias. Revise privacidade, informações comerciais e os detalhes do exame antes de publicar.</p><form method="post">';wp_nonce_field('otica_import');submit_button('Criar conteúdo inicial','primary','otica_import');echo '</form><hr><h2>Já instalou a versão anterior?</h2><p>Crie uma nova página inicial com o visual vermelho, branco e preto, fotografias e efeitos de rolagem. A página anterior e os dados das unidades e produtos serão preservados. Nada será publicado nem escolhido como página inicial automaticamente.</p><form method="post">';wp_nonce_field('otica_visual_v2');submit_button('Criar nova versão visual','primary','otica_visual_v2');echo '</form></div>';
}
function otica_seed(){
 $data=json_decode(file_get_contents(__DIR__.'/content.json'),true);
 foreach($data['stores'] as $i=>$s){$slug='unidade-'.($i+1);if(get_page_by_path($slug,OBJECT,'unidade'))continue;$id=wp_insert_post(['post_type'=>'unidade','post_status'=>'draft','post_title'=>$s[0],'post_name'=>$slug,'menu_order'=>$i],true);if(is_wp_error($id))continue;update_post_meta($id,'_otica_cidade',$s[1]);update_post_meta($id,'_otica_endereco',$s[2]);}
 foreach($data['products'] as $p){$slug=sanitize_title($p[0]);if(get_page_by_path($slug,OBJECT,'produto_otica'))continue;wp_insert_post(['post_type'=>'produto_otica','post_status'=>'draft','post_title'=>$p[0],'post_name'=>$slug,'post_content'=>'<!-- wp:paragraph --><p>'.esc_html($p[1]).'</p><!-- /wp:paragraph -->']);}
 foreach($data['pages'] as $slug=>$p){if(get_page_by_path($slug))continue;$body=preg_replace_callback('/PATTERN:([a-z-]+)\n/',function($m){$file=__DIR__.'/patterns/'.$m[1].'.php';ob_start();include $file;return ob_get_clean();},$p[1]);$id=wp_insert_post(['post_type'=>'page','post_status'=>'draft','post_name'=>$slug,'post_title'=>$p[0],'post_content'=>$body],true);if(!is_wp_error($id) && $slug==='inicio')update_post_meta($id,'_wp_page_template','vitrine');}
 $topics=['Quando realizar um exame de vista?','Como escolher a armação ideal?','Como cuidar dos seus óculos?','Diferenças entre tipos de lentes.','Importância da proteção UV.','Dicas para conservar seus óculos.'];
 $drafts=[
 'Mudanças na visão, dificuldade para ler ou desconforto merecem avaliação profissional. A frequência de acompanhamento varia conforme idade, histórico e orientação de quem cuida da sua saúde ocular. Converse com um profissional habilitado para definir quando retornar. Não adie a busca por atendimento diante de uma alteração súbita da visão.',
 'Além do formato, observe como a armação se apoia no nariz e nas orelhas. Ela deve ficar estável e confortável. A prescrição e as medidas das lentes também influenciam a escolha. Experimente diferentes opções com orientação e sem pressa.',
 'Siga as instruções do fabricante para limpeza. Evite produtos abrasivos, calor excessivo e apoiar as lentes diretamente sobre superfícies. Guarde seus óculos em um estojo apropriado e procure orientação para ajustes.',
 'Lentes monofocais, bifocais e multifocais atendem a necessidades diferentes. Materiais e tratamentos também variam. A seleção deve considerar sua prescrição, rotina e orientação profissional; nem toda opção é indicada para todas as pessoas.',
 'A cor escura da lente, sozinha, não comprova proteção contra radiação ultravioleta. Consulte as especificações do produto e escolha com orientação. A proteção adequada depende das características confirmadas pelo fabricante.',
 'Use as duas mãos para retirar os óculos, evite deixá-los no painel do carro e utilize um estojo ao transportá-los. Se notar folgas ou desconforto, peça um ajuste profissional em vez de dobrar a armação em casa.'
 ];
 $cat=term_exists('Dicas sobre visão','category');if(!$cat)$cat=wp_insert_term('Dicas sobre visão','category');$catid=is_wp_error($cat)?0:(int)(is_array($cat)?$cat['term_id']:$cat);
 foreach($topics as $i=>$title){$slug=sanitize_title($title);if(get_page_by_path($slug,OBJECT,'post'))continue;wp_insert_post(['post_type'=>'post','post_status'=>'draft','post_name'=>$slug,'post_title'=>$title,'post_category'=>$catid?[$catid]:[],'post_content'=>'<!-- wp:paragraph --><p>'.esc_html($drafts[$i]).'</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Conteúdo educativo provisório, sujeito à revisão por profissional habilitado. Não substitui consulta ou orientação individual.</p><!-- /wp:paragraph --><!-- wp:shortcode -->[otica_unidades]<!-- /wp:shortcode -->']);}
}

function otica_create_visual_v2(){
 if(!current_user_can('manage_options'))return new WP_Error('forbidden','Permissão insuficiente.');
 $existing=get_page_by_path('inicio-visual-2');if($existing)return $existing->ID;
 $data=json_decode(file_get_contents(__DIR__.'/content.json'),true);
 $body=preg_replace_callback('/PATTERN:([a-z-]+)\n/',function($m){ob_start();include __DIR__.'/patterns/'.$m[1].'.php';return ob_get_clean();},$data['pages']['inicio'][1]);
 $id=wp_insert_post(['post_type'=>'page','post_status'=>'draft','post_name'=>'inicio-visual-2','post_title'=>'Início — novo visual','post_content'=>$body],true);
 if(!is_wp_error($id))update_post_meta($id,'_wp_page_template','vitrine');return $id;
}
