# Rede de óticas — tema WordPress

Tema de blocos instalável, sem plugins pagos, Elementor ou compilação de produção. Nome, logotipo, fotografias e contatos comerciais permanecem pendentes. Não houve publicação externa.

## Arquitetura

- `tema/otica-rede/`: tema completo; `theme.json` controla cores, tipografia e espaçamento.
- `templates/` e `parts/`: modelos de páginas, artigos, arquivos, erro 404, cabeçalho e rodapé, editáveis no Editor do site.
- `patterns/`: banners, vitrine, unidades, benefícios, chamada comercial e agendamento reutilizáveis.
- `functions.php`: tipos de conteúdo, metadados comerciais protegidos por permissão/nonce, shortcodes, SEO e recursos de interface.
- `inc.php` e `content.json`: instalador opcional e repetível do conteúdo inicial. Não sobrescreve conteúdos com os mesmos slugs.
- `assets/`: CSS, JavaScript e ilustrações provisórias locais; sem fontes externas, pixels ou chamadas de mapas automáticas.
- `dev/`: WordPress Playground/PHP 8.3 para demonstração local e testes em Chromium. Não precisa ser enviado à Hostinger.
- `dist/otica-rede.zip`: arquivo instalável. Capturas de desktop e celular acompanham a entrega.

## Instalar na Hostinger

1. Faça backup de um site existente. No hPanel, use o instalador WordPress da Hostinger, habilite HTTPS e escolha a versão estável atual do WordPress com PHP 8.3 ou superior. O tema exige WordPress 6.6+ e PHP 8.0+; validado localmente em WordPress 6.8 / PHP 8.3, sem teste no servidor da Hostinger.
2. No WordPress: **Aparência → Temas → Adicionar tema → Enviar tema**. Envie `dist/otica-rede.zip` e ative.
3. Vá a **Aparência → Preparar site → Criar conteúdo inicial**. O instalador é opcional, não troca a página inicial e cria os conteúdos em **rascunho**. Repita sem duplicar slugs existentes.
4. Revise as sete páginas em **Páginas**: Início, Nossas lojas, Produtos, Agendamento, Dicas sobre visão, Sobre nós e Política de Privacidade. Troque todo material provisório e revise os artigos antes de publicar.
5. Em **Unidades**, revise as cinco lojas, endereços, fachadas, horários confirmados e WhatsApps. Use `55` + DDD + número, só dígitos. Não há telefones inventados. Números inválidos são recusados com aviso; campo vazio mantém o envio indisponível. Publique apenas as unidades aprovadas. Unidades em rascunho são visíveis nos componentes somente para editores autenticados.
6. Em **Produtos e categorias**, substitua as ilustrações por imagens destacadas, edite descrições e publique os itens aprovados. Adicione categorias no submenu próprio se necessário.
7. Publique as páginas aprovadas. Em **Configurações → Leitura**, selecione uma página estática e escolha **Início**. Deixe a página de posts sem seleção: a página Dicas sobre visão já inclui uma consulta nativa editável. Se preferir definir uma página de posts, o modelo de índice do tema também está preparado.
8. Em **Configurações → Links permanentes**, escolha Nome do post e salve. Verifique rotas de lojas, produtos e artigos. O sitemap nativo fica em `/wp-sitemap.xml`, se a indexação estiver permitida.
9. Em **Configurações → Privacidade**, associe a página revisada. Revise também e-mail administrativo, fuso horário, título e descrição do site.
10. Em **Aparência → Editor**, configure o nome real, logotipo, menus, links sociais e rodapé. Os links sem domínio são resolvidos para o endereço do seu WordPress, inclusive instalações em subdiretório.
11. Teste uma solicitação real com cada unidade antes de divulgar. Confirme no celular a abertura do WhatsApp e a recepção da mensagem. Só depois habilite indexação e faça a publicação/divulgação desejada.

O ZIP deve conter a pasta `otica-rede` diretamente, não a pasta do projeto inteiro. Não envie `dev`, bancos locais ou `node_modules` à hospedagem.

## Editar sem programação

| Alteração | Onde editar |
|---|---|
| Banner, título, texto, botões e foto principal | Páginas → Início → Editar; selecione o bloco de imagem e Substituir |
| Cores e fontes | Aparência → Editor → Estilos; use as cores nomeadas da paleta |
| Cabeçalho fixo, logotipo, menu e rodapé | Aparência → Editor → Design → Padrões/Partes de modelo; navegação usa bloco nativo |
| Endereço, cidade, WhatsApp e horário | Unidades → editar → Informações comerciais |
| Fachada e apresentação da loja | Unidades → imagem destacada e conteúdo Gutenberg |
| Adicionar/remover loja | Unidades → adicionar/publicar ou mover para lixeira; cartões e formulário acompanham automaticamente |
| Vitrine, foto, título e descrição | Produtos e categorias → editar; imagem destacada e blocos nativos |
| Novas categorias e produtos | Produtos e categorias; use as taxonomias do submenu para organizar |
| Artigos e imagens destacadas | Posts → adicionar; categorias nativas do WordPress |
| História, missão e valores | Páginas → Sobre nós |
| Novas páginas e campanhas | Páginas → adicionar; Inserir → Padrões → Rede de óticas |
| Descrição SEO | Caixa Descrição para buscadores ao editar página/artigo/produto/unidade; o título nativo é o título SEO |
| Novos botões sociais | Adicione um bloco nativo Ícones sociais com URLs reais ao rodapé |

**Limitação deliberada do Gutenberg:** cartões de lojas, opções do formulário e vitrine são renderizados dinamicamente por shortcodes. Edite os dados em **Unidades** e **Produtos e categorias**, em vez de tentar alterar cada cartão na página. O contexto ao redor desses componentes, banners, benefícios, botões e páginas permanece editável visualmente. As perguntas e as regras do formulário ficam no código do tema; alterações na lógica exigem manutenção técnica. Os padrões inseridos são cópias independentes; transforme-os em padrões sincronizados pelo WordPress se quiser alterações globais.

Os cadastros são tipos de conteúdo registrados pelo tema. Trocar de tema mantém os dados no banco, mas oculta os menus/componentes até reativar este tema ou migrar seu registro para um plugin. Para trocar radicalmente o desenho do formulário, cabeçalho ou efeitos é necessário editar o tema; cores e conteúdo não exigem isso.

## Agendamento e privacidade

Fluxo: último exame → unidade → dados/consentimento → revisão e envio. A seleção nos cartões é mantida no formulário por parâmetro `otica_unidade` e, na página inicial, diretamente no formulário. Nome completo, telefone, período e consentimento são obrigatórios. Mensagem construída com `encodeURIComponent`; revisão usa `textContent`, evitando interpretar nomes como HTML.

O tema não recebe nem armazena esses dados no servidor ou localStorage. O WhatsApp abre somente após ação do visitante. O link é preenchido, mas a mensagem ainda precisa ser enviada pelo visitante. Nenhum horário é confirmado automaticamente. Sem WhatsApp válido na loja, o botão final é bloqueado e a pendência é exibida. O botão flutuante abre a seleção de unidade, pois não existe um número geral confirmado.

O mapa incorporado só carrega após clique, indicando conexão com Google. Como chegar abre a pesquisa pelo endereço completo. A posição exata dos pinos deve ser conferida pelo responsável pelas lojas. Dados estruturados `Optician` incluem somente nome descritivo da unidade, endereço, URL e telefone cadastrado; não incluem avaliações, certificações, coordenadas, horários ou serviços presumidos.

## SEO, métricas e publicidade

URLs amigáveis e sitemap são recursos nativos. Descrições são configuráveis no painel; não duplique metatags com um plugin SEO. Caso use um plugin, remova/desative a saída de descrição deste tema por manutenção técnica ou use apenas os demais recursos do plugin. Artigos têm modelos com imagem destacada, categorias, conteúdos relacionados que excluem o artigo atual e CTA.

Nenhum GA4, GTM, Google Ads ou Meta Pixel foi ativado: faltam identificadores reais e a política de consentimento. É possível configurá-los posteriormente com plugins gratuitos próprios para WordPress e um gerenciador de consentimento compatível. Não cole IDs ou scripts aleatórios nos conteúdos. Valide Tags/Pixel e bloqueio antes do consentimento com seu responsável de marketing.

Ganchos de conversão: `data-conversion="appointment-whatsapp"`, `store-whatsapp`, `directions`, `product-contact` e `floating-whatsapp`. Um evento DOM `otica:conversion` é emitido com `detail.action`, **sem dados pessoais**. O disparo é intenção de contato, não comprovação de agendamento ou mensagem enviada. Um integrador pode conectar esse evento ao `dataLayer` após o consentimento apropriado. O tema não envia automaticamente eventos a terceiros.

## Desenvolvimento e demonstração local

Node 24.18+ (recomendado npm 11.16+), Python 3, curl e zip. O servidor WordPress roda em PHP/WASM com SQLite para avaliação; produção na Hostinger usa o WordPress normal com MySQL/MariaDB. **Use o checkout existente; o ambiente já é isolado, não crie worktrees.**

```bash
cd /workspace/site-tica
bash dev/setup.sh
bash dev/start.sh
```

O servidor fica na porta local 9400. Não há publicação ou link público de prévia. O blueprint publica conteúdo **apenas na demonstração local** para permitir sua avaliação. Não use esse blueprint, servidor ou credenciais padrão do Playground na Hostinger. O banco demonstrativo fica em `dev/.runtime`, ignorado pelo Git. O início não sobrescreve edições já feitas no conteúdo local. Para uma demonstração totalmente limpa, pare seu servidor e arquive `dev/.runtime` antes de executar novamente o setup.

Verificações com o servidor ativo:

```bash
node dev/smoke.cjs
node dev/editor-check.cjs
```

O teste usa dados fictícios somente no DOM, sem persistir telefones de lojas e sem enviar mensagens. O Chromium de teste é obtido por pacote npm com integridade de lockfile. O instalador baixa o código oficial do WordPress pelo GitHub com TLS verificado, pois o acesso direto a wordpress.org pode estar bloqueado neste ambiente. Os pacotes npm usam o lockfile. Não é necessário acesso à Hostinger, chave API ou serviço pago para executar a demonstração.

Empacotar o tema:

```bash
cd /workspace/site-tica
python3 dev/package.py
```

## Pendências antes da publicação

- Nome comercial real, razão social, logotipo e aprovação da paleta.
- Fotografias licenciadas de pessoas usando óculos, produtos e fachadas; as ilustrações são provisórias e não representam produtos reais ou lojas.
- WhatsApp de cada unidade, horários e redes sociais confirmados.
- História, missão, valores e aprovação do texto institucional sugerido.
- Confirmar condições do exame, disponibilidade, profissionais responsáveis e linguagem comercial adequada à operação real.
- Revisão dos seis artigos educativos e de suas imagens por responsável qualificado.
- Revisão jurídica da política, identificação e contato do controlador, retenção no atendimento das lojas e canal de direitos.
- IDs de marketing/analytics se desejados, configuração e teste de consentimento.
- Teste na hospedagem final, envio real de mensagem, posição de mapas, domínio/HTTPS e SEO final.

A configuração de nuvem salva prepara o desenvolvimento e a demonstração; não publica o site nem o ambiente automaticamente.
