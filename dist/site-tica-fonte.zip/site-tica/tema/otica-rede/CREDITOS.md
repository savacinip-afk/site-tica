# Créditos das fotografias de referência

Fotografias de banco de imagem, não clientes, funcionários, produtos do estoque ou fachadas da rede. Substitua por material próprio quando disponível. Nenhum depoimento ou endosso é atribuído às pessoas retratadas.

Imagens disponibilizadas originalmente no Unsplash (licença padrão: https://unsplash.com/license). Recuperadas de cópias versionadas no repositório público renchester/eyewear-shop, revisão 9b838cd; a atribuição original está em credits.md desse repositório. Não foram utilizadas imagens identificadas como Unsplash+ nem fotografias comerciais de catálogo Ronnie & Joe. Somente as fotografias listadas abaixo foram aproveitadas; código e design desse repositório não foram utilizados.

- `hero-style.webp`: Christopher Ott — https://unsplash.com/@notso — arquivo de origem hero-5.webp.
- `grau.webp`: Tamara Bellis — https://unsplash.com/@tamarabellis — frame-5.webp.
- `sol.webp`: Brooke Cagle — https://unsplash.com/@brookecagle — sun-5.webp.
- `armacoes.webp`: Eyekeeper — https://unsplash.com/@eyekeeper — ad-7.webp.
- `lentes.webp`: Fernando Lavin — https://unsplash.com/@filmlav — ad-5.webp.
- `pessoas.webp`: Kelly Sikkema — https://unsplash.com/@kellysikkema — frame-4.webp.

Fontes locais: Manrope (Mikhail Sharanda e colaboradores) e Barlow Condensed (Jeremy Tribby), distribuídas pelo projeto Google Fonts sob SIL Open Font License. Licenças completas em assets/fonts/.
