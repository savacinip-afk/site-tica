(()=>{
const f=document.querySelector('#appointment-form');if(!f)return;
let step=0;const panels=[...f.querySelectorAll('[data-step]')], error=f.querySelector('#form-error'),next=f.querySelector('#next-step'),prev=f.querySelector('#prev-step');
const selected=()=>f.querySelector('[name="store"]:checked');
function choose(id){const radio=[...f.querySelectorAll('[name="store"]')].find(r=>r.value===String(id));if(radio)radio.checked=true;}
choose(new URLSearchParams(location.search).get('otica_unidade'));
document.querySelectorAll('[data-store]').forEach(a=>a.addEventListener('click',e=>{if(location.pathname==='/' || location.pathname.endsWith('/agendamento/')){e.preventDefault();choose(a.dataset.store);document.querySelector('#agendamento').scrollIntoView({behavior:'smooth'});}}));
function render(){panels.forEach((p,i)=>p.hidden=i!==step);f.querySelectorAll('.progress span').forEach((p,i)=>{p.classList.toggle('active',i<=step);if(i===step)p.setAttribute('aria-current','step');else p.removeAttribute('aria-current');});prev.hidden=step===0;next.hidden=step===3;error.textContent='';f.querySelector('#step-status').textContent=`Etapa ${step+1} de 4`;if(step===3)review();}
function valid(){const fields=[...panels[step].querySelectorAll('input,select')];for(const field of fields){if(!field.checkValidity()){error.textContent='Preencha os campos obrigatórios para continuar.';field.reportValidity();field.focus();return false;}}
if(step===2){const n=f.elements.customer.value.trim(),p=f.elements.phone.value.replace(/\D/g,'');if(!/^\S+\s+\S+/.test(n)){error.textContent='Informe seu nome completo.';f.elements.customer.focus();return false;}if(!/^(?:55)?[1-9][0-9]{9,10}$/.test(p)){error.textContent='Informe um WhatsApp válido com DDD (10 ou 11 dígitos; código 55 opcional).';f.elements.phone.focus();return false;}}return true;}
function review(){const store=selected(),data=new FormData(f);const lines=[['Nome',data.get('customer').trim()],['WhatsApp',data.get('phone')],['Último exame',data.get('exam')],['Unidade escolhida',store.dataset.name],['Melhor período',data.get('period')]];const target=f.querySelector('#appointment-review');target.replaceChildren();lines.forEach(([k,v])=>{const p=document.createElement('p'),b=document.createElement('strong');b.textContent=k+': ';p.append(b,document.createTextNode(v));target.append(p);});const a=f.querySelector('#whatsapp-submit'),has=/^55[1-9][0-9]{9,10}$/.test(store.dataset.phone);a.hidden=!has;f.querySelector('#missing-phone').hidden=has;if(has)a.href='https://wa.me/'+store.dataset.phone+'?text='+encodeURIComponent('Olá! Gostaria de solicitar um agendamento de exame de vista.\n\n'+lines.map(([k,v])=>k+': '+v).join('\n'));else a.removeAttribute('href');}
next.addEventListener('click',()=>{if(valid()){step++;render();panels[step].querySelector('legend').setAttribute('tabindex','-1');panels[step].querySelector('legend').focus();}});prev.addEventListener('click',()=>{step--;render();});f.addEventListener('submit',e=>e.preventDefault());render();
})();
// Sinal de conversão sem dados pessoais. Integrações de marketing precisam de consentimento configurado pelo responsável.
document.addEventListener('click',e=>{const a=e.target.closest('[data-conversion]');if(a)document.dispatchEvent(new CustomEvent('otica:conversion',{detail:{action:a.dataset.conversion}}));});

document.querySelectorAll('.load-map').forEach(button=>button.addEventListener('click',()=>{const iframe=document.createElement('iframe');iframe.src=button.dataset.map;iframe.title='Mapa da localização da unidade';iframe.loading='lazy';iframe.referrerPolicy='no-referrer';iframe.style.cssText='width:100%;height:250px;border:0;margin-top:16px';button.replaceWith(iframe);}));

// Exploradores funcionam com toque, mouse e teclado. Sem dependências externas.
(()=>{
 document.querySelectorAll('[data-store-explorer]').forEach(explorer=>{
  const buttons=[...explorer.querySelectorAll('[data-city-filter]')],cards=[...explorer.querySelectorAll('.store-card')];
  buttons.forEach(button=>button.addEventListener('click',()=>{buttons.forEach(b=>{const active=b===button;b.classList.toggle('is-active',active);b.setAttribute('aria-pressed',String(active));});let visible=0;cards.forEach(card=>{card.hidden=button.dataset.cityFilter!=='*' && card.dataset.city!==button.dataset.cityFilter;if(!card.hidden){visible++;card.classList.add('is-visible');}});explorer.querySelector('.filter-status').textContent=`${visible} ${visible===1?'unidade encontrada':'unidades encontradas'}.`;}));
 });
 document.querySelectorAll('[data-product-explorer]').forEach(explorer=>{
  const buttons=[...explorer.querySelectorAll('[data-product-filter]')],cards=[...explorer.querySelectorAll('.product-card')],grid=explorer.querySelector('.products-grid');
  buttons.forEach(button=>button.addEventListener('click',()=>{buttons.forEach(b=>{const active=b===button;b.classList.toggle('is-active',active);b.setAttribute('aria-pressed',String(active));});let visible=0;grid.classList.toggle('is-filtered',button.dataset.productFilter!=='*');cards.forEach(card=>{card.hidden=button.dataset.productFilter!=='*' && card.dataset.productId!==button.dataset.productFilter;if(!card.hidden){visible++;card.classList.add('is-visible');}});explorer.querySelector('.filter-status').textContent=`${visible} ${visible===1?'categoria selecionada':'categorias disponíveis'}.`;}));
 });
 const triggers=[...document.querySelectorAll('[data-open-product]')];
 if(triggers.length && typeof HTMLDialogElement!=='undefined'){
  const dialog=document.createElement('dialog');dialog.className='product-dialog';dialog.setAttribute('aria-labelledby','product-dialog-title');
  dialog.innerHTML='<button type="button" class="dialog-close" aria-label="Fechar detalhes">×</button><div class="dialog-grid"><img class="dialog-image" alt=""><div class="dialog-copy"><p class="eyebrow">EXPLORE SEU PRÓXIMO OLHAR</p><h2 id="product-dialog-title"></h2><p class="dialog-description"></p><a class="button" data-conversion="product-contact">FALAR COM UMA UNIDADE ↗︎</a><p class="fine">Fotografia de referência. Consulte modelos e disponibilidade diretamente com a unidade.</p></div></div>';
  const contact=document.querySelector('.product-card [data-conversion="product-contact"]');if(contact)dialog.querySelector('.button').href=contact.href;
  document.body.append(dialog);let trigger;
  triggers.forEach(button=>button.addEventListener('click',()=>{trigger=button;const card=button.closest('.product-card'),img=dialog.querySelector('.dialog-image');img.src=card.dataset.productImage;img.alt=card.dataset.productTitle+' — fotografia de referência';dialog.querySelector('h2').textContent=card.dataset.productTitle;dialog.querySelector('.dialog-description').textContent=card.dataset.productDescription;dialog.showModal();dialog.querySelector('.dialog-close').focus();}));
  dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog){const rect=dialog.getBoundingClientRect();if(e.clientX<rect.left || e.clientX>rect.right || e.clientY<rect.top || e.clientY>rect.bottom)dialog.close();}});dialog.addEventListener('close',()=>{if(trigger)trigger.focus({preventScroll:true});});
 }
})();

// Rolagem nativa com progressão, profundidade fotográfica e revelação de conteúdo.
(()=>{
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(pointer:fine)');
 const progress=document.createElement('div');progress.className='scroll-progress';progress.setAttribute('aria-hidden','true');document.body.append(progress);
 const header=document.querySelector('.site-header'),hero=document.querySelector('.hero-v2'),heroImage=document.querySelector('.hero-v2 .hero-photo img');
 let ticking=false;
 function scrollFrame(){const y=window.scrollY,total=document.documentElement.scrollHeight-innerHeight;progress.style.transform=`scaleX(${total>0?Math.min(y/total,1):0})`;if(header)header.classList.toggle('is-scrolled',y>30);if(heroImage && hero && !reduced.matches){const rect=hero.getBoundingClientRect();if(rect.bottom>0 && rect.top<innerHeight)heroImage.style.setProperty('--hero-parallax',`${Math.max(-60,Math.min(60,-rect.top*.075))}px`);}ticking=false;}
 addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(scrollFrame);ticking=true;}},{passive:true});addEventListener('resize',scrollFrame,{passive:true});scrollFrame();
 if('IntersectionObserver' in window){
  const targets=[...document.querySelectorAll('.section-heading,.product-card,.store-card,.benefit,.story-visual,.story-copy,.appointment,.closing-section .section-inner,.watches-section .watch-card,.brands-section .brand-carousel,.influencer-card,.about-preview-grid,.team-card,.careers-section .section-inner')];
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target);}}),{threshold:.07,rootMargin:'0px 0px -25px 0px'});
  targets.forEach((el,i)=>{el.classList.add('reveal');el.style.setProperty('--reveal-delay',`${el.matches('.product-card,.benefit,.store-card')?(i%3)*65:0}ms`);if(el.getBoundingClientRect().bottom<0)el.classList.add('is-visible');else observer.observe(el);});
  document.documentElement.classList.add('motion-ready');
  document.addEventListener('focusin',e=>{const parent=e.target.closest('.reveal');if(parent)parent.classList.add('is-visible');});
 }
 document.querySelectorAll('.product-image-button').forEach(card=>{
  card.addEventListener('pointermove',e=>{if(reduced.matches || !fine.matches)return;const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;card.style.transform=`perspective(1200px) rotateX(${-y*3}deg) rotateY(${x*3}deg)`;});
  card.addEventListener('pointerleave',()=>{card.style.transform='';});
 });
})();

// Carrossel de marcas: 15 posições iniciais, extremidades cortadas, ciclo contínuo.
(()=>{
 document.querySelectorAll('[data-brand-carousel]').forEach(root=>{
  const viewport=root.querySelector('.brand-viewport'),track=root.querySelector('.brands-track'),originals=[...track.querySelectorAll('[data-brand-original]')],count=originals.length;
  const prev=root.querySelector('[data-brand-prev]'),next=root.querySelector('[data-brand-next]'),pause=root.querySelector('[data-brand-pause]'),position=root.querySelector('.brand-position'),announcement=root.querySelector('.brand-announcement');
  if(count<2){root.classList.add('single-brand');[prev,next,pause].forEach(b=>b.disabled=true);return;}
  const clone=item=>{const copy=item.cloneNode(true);copy.removeAttribute('data-brand-original');copy.setAttribute('data-brand-clone','');copy.setAttribute('aria-hidden','true');copy.setAttribute('inert','');return copy;};
  const before=document.createDocumentFragment(),after=document.createDocumentFragment();originals.forEach(item=>{before.append(clone(item));after.append(clone(item));});track.prepend(before);track.append(after);
  root.classList.add('is-enhanced');const cards=[...track.children],reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let index=count,itemWidth=0,gap=24,timer=null,normalizer=null,busy=false,touchX=null;
  const stopped={user:false,hover:false,focus:false,outside:true};
  const current=()=>((index-count)%count+count)%count;
  function paint(animate=false){
   track.style.transition=animate && !reduced.matches?'transform 650ms cubic-bezier(.22,.7,.25,1)':'none';
   track.style.transform=`translate3d(${-index*(itemWidth+gap)-itemWidth/2}px,0,0)`;
   position.textContent=String(current()+1).padStart(2,'0')+' / '+String(count).padStart(2,'0');
   const units=viewport.clientWidth<600?2:4;cards.forEach((card,i)=>card.classList.toggle('is-featured',i===index+units/2));
  }
  function normalize(){clearTimeout(normalizer);if(index>=2*count)index-=count;else if(index<count)index+=count;paint(false);busy=false;}
  function step(direction,manual=false){if(busy)return;index+=direction;busy=!reduced.matches;paint(true);if(manual)announcement.textContent='Posição '+(current()+1)+' de '+count+'.';if(busy)normalizer=setTimeout(normalize,690);else normalize();}
  function schedule(){clearInterval(timer);timer=null;if(!reduced.matches && !document.hidden && !Object.values(stopped).some(Boolean))timer=setInterval(()=>step(1),3400);}
  function pauseLabel(){const disabled=reduced.matches;pause.disabled=disabled;pause.setAttribute('aria-pressed',String(disabled||stopped.user));pause.setAttribute('aria-label',disabled?'Movimento automático desativado pela preferência de movimento reduzido':stopped.user?'Retomar movimento automático':'Pausar movimento automático');pause.textContent='';}
  function measure(){normalize();gap=parseFloat(getComputedStyle(root).getPropertyValue('--brand-gap'))||24;const units=viewport.clientWidth<600?2:4;itemWidth=Math.max(50,(viewport.clientWidth-units*gap)/units);root.style.setProperty('--brand-item',itemWidth+'px');paint(false);}
  prev.addEventListener('click',()=>step(-1,true));next.addEventListener('click',()=>step(1,true));pause.addEventListener('click',()=>{stopped.user=!stopped.user;if(!stopped.user)stopped.focus=false;pauseLabel();schedule();});
  root.addEventListener('mouseenter',()=>{stopped.hover=true;schedule();});root.addEventListener('mouseleave',()=>{stopped.hover=false;schedule();});
  root.addEventListener('focusin',()=>{stopped.focus=true;schedule();});root.addEventListener('focusout',()=>requestAnimationFrame(()=>{stopped.focus=root.contains(document.activeElement);schedule();}));
  viewport.addEventListener('keydown',event=>{if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();step(event.key==='ArrowRight'?1:-1,true);}});
  viewport.addEventListener('pointerdown',event=>{if(event.pointerType==='touch')touchX=event.clientX;},{passive:true});viewport.addEventListener('pointerup',event=>{if(touchX!==null && Math.abs(event.clientX-touchX)>35)step(event.clientX<touchX?1:-1,true);touchX=null;},{passive:true});viewport.addEventListener('pointercancel',()=>{touchX=null;},{passive:true});
  track.addEventListener('transitionend',event=>{if(event.propertyName==='transform' && busy)normalize();});
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{stopped.outside=!entries[0].isIntersecting;schedule();},{threshold:.1}).observe(root);else stopped.outside=false;
  if('ResizeObserver' in window)new ResizeObserver(measure).observe(viewport);else addEventListener('resize',measure,{passive:true});
  document.addEventListener('visibilitychange',schedule);reduced.addEventListener('change',()=>{normalize();pauseLabel();schedule();});measure();pauseLabel();schedule();
 });
})();
