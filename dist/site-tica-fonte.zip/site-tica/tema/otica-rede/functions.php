<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/inc.php';
require_once __DIR__ . '/community.php';
add_action('after_setup_theme', function () {
 add_theme_support('post-thumbnails'); add_theme_support('title-tag'); add_theme_support('editor-styles'); add_editor_style('assets/site.css');
});
add_action('wp_enqueue_scripts', function () {
 wp_enqueue_style('otica-site', get_theme_file_uri('assets/site.css'), [], '2.2.0');
 wp_enqueue_script('otica-site', get_theme_file_uri('assets/site.js'), [], '2.2.0', true);
});
add_action('init', function () {
 register_post_type('unidade', ['labels'=>['name'=>'Unidades','singular_name'=>'Unidade','add_new_item'=>'Adicionar unidade'],'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-location','supports'=>['title','editor','thumbnail','page-attributes'],'has_archive'=>false,'rewrite'=>['slug'=>'unidade']]);
 register_post_type('produto_otica', ['labels'=>['name'=>'Produtos e categorias','singular_name'=>'Produto ou categoria'],'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-visibility','supports'=>['title','editor','thumbnail','excerpt'],'rewrite'=>['slug'=>'produto']]);
 foreach (['endereco','whatsapp','horario','cidade'] as $key) register_post_meta('unidade', '_otica_'.$key, ['type'=>'string','single'=>true,'show_in_rest'=>true,'sanitize_callback'=>'sanitize_text_field','auth_callback'=>function(){return current_user_can('edit_posts');}]);
 register_taxonomy('categoria_otica', 'produto_otica', ['label'=>'Categorias de produtos','public'=>true,'hierarchical'=>true,'show_in_rest'=>true]);
 register_block_pattern_category('otica', ['label'=>'Rede de óticas']);
});
add_action('add_meta_boxes',function(){
 add_meta_box('otica-dados','Informações comerciais da unidade',function($post){
 wp_nonce_field('otica_save','otica_nonce');
 foreach(['cidade'=>'Cidade','endereco'=>'Endereço completo','whatsapp'=>'WhatsApp (55 + DDD + número; deixe vazio se pendente)','horario'=>'Horário de atendimento (somente confirmado)'] as $key=>$label) {
 echo '<p><label for="otica-'.esc_attr($key).'">'.esc_html($label).'</label><br><input style="width:100%" id="otica-'.esc_attr($key).'" name="otica_'.esc_attr($key).'" value="'.esc_attr(get_post_meta($post->ID,'_otica_'.$key,true)).'"></p>';
 }
 echo '<p>A imagem destacada será a fachada. Não use fotografia de outra loja. Sem WhatsApp cadastrado, o envio ficará indisponível.</p>';
 },'unidade','normal','high');
});
add_action('save_post_unidade',function($id){
 if(!isset($_POST['otica_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['otica_nonce'])),'otica_save') || !current_user_can('edit_post',$id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE))return;
 foreach(['cidade','endereco','whatsapp','horario'] as $key) {
 $value=sanitize_text_field(wp_unslash($_POST['otica_'.$key] ?? ''));
 if($key==='whatsapp'){ $value=preg_replace('/\D/','',$value);if($value && !preg_match('/^55[1-9][0-9]{9,10}$/',$value)){set_transient('otica_phone_error_'.get_current_user_id(),true,60);continue;} }
 update_post_meta($id,'_otica_'.$key,$value);
 }
});
function otica_stores(){ return get_posts(['post_type'=>'unidade','post_status'=>current_user_can('edit_posts')?['publish','draft']:['publish'],'numberposts'=>-1,'orderby'=>'menu_order ID','order'=>'ASC']); }
function otica_phone($id){$p=get_post_meta($id,'_otica_whatsapp',true);return preg_match('/^55[1-9][0-9]{9,10}$/',$p)?$p:'';}
add_shortcode('otica_unidades',function($atts){
 $full=isset($atts['completo']) && $atts['completo']==='sim'; $stores=otica_stores(); $cities=[];foreach($stores as $store){$city=get_post_meta($store->ID,'_otica_cidade',true);if($city && !in_array($city,$cities,true))$cities[]=$city;}
 ob_start();echo '<div class="stores-explorer" data-store-explorer>';if($cities){echo '<div class="filter-pills" role="group" aria-label="Filtrar unidades por cidade"><button type="button" class="filter-pill is-active" data-city-filter="*" aria-pressed="true">Todas as cidades</button>';foreach($cities as $city)echo '<button type="button" class="filter-pill" data-city-filter="'.esc_attr($city).'" aria-pressed="false">'.esc_html($city).'</button>';echo '</div>';} echo '<p class="filter-status screen-reader-text" aria-live="polite"></p><div class="stores-grid">';
 foreach(otica_stores() as $i=>$s){ $addr=get_post_meta($s->ID,'_otica_endereco',true); $phone=otica_phone($s->ID); $map='https://www.google.com/maps/search/?api=1&query='.rawurlencode($addr); ?>
 <article class="store-card" data-city="<?php echo esc_attr(get_post_meta($s->ID,'_otica_cidade',true)); ?>" id="unidade-<?php echo esc_attr($s->ID); ?>"><span class="eyebrow">UNIDADE <?php echo esc_html(str_pad((string)($i+1),2,'0',STR_PAD_LEFT)); ?></span>
 <?php if($full && has_post_thumbnail($s)) echo get_the_post_thumbnail($s,'large',['loading'=>'lazy']); ?>
 <h3><?php echo esc_html($s->post_title); ?></h3><p><?php echo esc_html($addr); ?></p>
 <?php if($full): ?><p><?php echo esc_html(get_post_meta($s->ID,'_otica_horario',true)); ?></p><div><?php echo apply_filters('the_content',$s->post_content); ?></div><button type="button" class="secondary small load-map" data-map="<?php echo esc_url('https://www.google.com/maps?q='.rawurlencode($addr).'&output=embed'); ?>">Carregar mapa da localização</button><p class="map-note">Ao carregar o mapa, você se conecta ao Google. Também pode usar o link Como chegar.</p><?php endif; ?>
 <div class="store-actions"><a href="<?php echo esc_url($map); ?>" target="_blank" rel="noopener noreferrer" data-conversion="directions">Como chegar ↗︎</a><a class="button small" data-store="<?php echo esc_attr($s->ID); ?>" href="<?php echo esc_url(home_url('/agendamento/')); ?>?otica_unidade=<?php echo esc_attr($s->ID); ?>#agendamento">Agendar exame</a>
 <?php if($full && $phone): ?><a href="<?php echo esc_url('https://wa.me/'.$phone); ?>" data-conversion="store-whatsapp" target="_blank" rel="noopener noreferrer">Falar pelo WhatsApp ↗︎</a><?php elseif($full): ?><span class="pending">WhatsApp aguardando cadastro</span><?php endif; ?></div></article>
 <?php } echo '</div></div>';return ob_get_clean();
});
add_shortcode('otica_agendamento',function(){ob_start(); ?>
<section class="appointment" id="agendamento" aria-labelledby="appointment-title"><div><span class="eyebrow">UM NOVO OLHAR COMEÇA AQUI</span><h2 id="appointment-title">QUANDO FOI<br>SEU ÚLTIMO<br><em>EXAME DE VISTA?</em></h2><p>Sua visão merece atenção. Responda algumas perguntas e solicite seu agendamento.</p><p class="fine">A solicitação não confirma o agendamento. Aguarde o retorno da unidade para combinar disponibilidade, condições e profissional responsável.</p></div>
<form id="appointment-form" novalidate><div class="progress" aria-label="Progresso"><span class="active">1. Seu exame</span><span>2. Unidade</span><span>3. Seus dados</span><span>4. Finalizar</span></div>
<fieldset data-step="0"><legend>Há quanto tempo você realizou seu último exame de vista?</legend><?php foreach(['Há menos de 1 ano.','Há mais de 1 ano.','Não me lembro.'] as $v): ?><label class="choice"><input type="radio" name="exam" value="<?php echo esc_attr($v); ?>" required> <?php echo esc_html($v); ?></label><?php endforeach; ?></fieldset>
<fieldset data-step="1" hidden><legend>Escolha sua unidade</legend><?php foreach(otica_stores() as $s): ?><label class="choice"><input type="radio" name="store" value="<?php echo esc_attr($s->ID); ?>" data-name="<?php echo esc_attr($s->post_title); ?>" data-phone="<?php echo esc_attr(otica_phone($s->ID)); ?>" required><span><?php echo esc_html($s->post_title); ?><small><?php echo esc_html(get_post_meta($s->ID,'_otica_endereco',true)); ?></small></span></label><?php endforeach; ?></fieldset>
<fieldset data-step="2" hidden><legend>Como podemos falar com você?</legend><label>Nome completo<input name="customer" autocomplete="name" minlength="3" maxlength="120" required></label><label>WhatsApp com DDD<input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="(DD) 99999-9999" maxlength="22" required></label><label>Melhor período<select name="period" required><option value="">Selecione</option><option>Manhã</option><option>Tarde</option><option>Indiferente</option></select></label><label class="consent"><input type="checkbox" name="consent" required><span>Concordo com a utilização dos dados exclusivamente para responder à solicitação, conforme a <a href="<?php echo esc_url(home_url('/politica-de-privacidade/')); ?>" target="_blank" rel="noopener">Política de Privacidade</a>.</span></label></fieldset>
<fieldset data-step="3" hidden><legend>Confira sua solicitação</legend><div id="appointment-review"></div><p>Ao continuar, você abrirá o WhatsApp. Envie a mensagem para solicitar seu horário. O agendamento depende da confirmação da unidade.</p><a id="whatsapp-submit" class="button" data-conversion="appointment-whatsapp" target="_blank" rel="noopener noreferrer" hidden>Solicitar agendamento pelo WhatsApp ↗︎</a><p id="missing-phone" hidden>Esta unidade ainda não cadastrou o WhatsApp. Escolha outra unidade ou consulte o endereço em Nossas lojas.</p></fieldset>
<p id="form-error" class="error" role="alert" aria-live="polite"></p><div class="form-navigation"><button type="button" id="prev-step" class="secondary" hidden>Voltar</button><button type="button" id="next-step">Continuar →</button></div><p id="step-status" class="fine" aria-live="polite">Etapa 1 de 4</p></form></section>
<?php return ob_get_clean();});
add_shortcode('otica_produtos',function(){
 $items=get_posts(['post_type'=>'produto_otica','post_status'=>current_user_can('edit_posts')?['publish','draft']:['publish'],'numberposts'=>-1,'orderby'=>'ID','order'=>'ASC']);
 $photos=['oculos-de-grau'=>'grau','oculos-de-sol'=>'sol','armacoes'=>'armacoes','lentes'=>'lentes'];ob_start();
 echo '<div class="product-explorer" data-product-explorer><div class="filter-pills" role="group" aria-label="Filtrar categorias"><button type="button" class="filter-pill is-active" data-product-filter="*" aria-pressed="true">Explore todos</button>';
 foreach($items as $item)echo '<button type="button" class="filter-pill" data-product-filter="'.esc_attr($item->ID).'" aria-pressed="false">'.esc_html($item->post_title).'</button>';
 echo '</div><p class="filter-status screen-reader-text" aria-live="polite"></p><div class="products-grid">';
 foreach($items as $i=>$p){$photo=has_post_thumbnail($p)?get_the_post_thumbnail_url($p,'large'):get_theme_file_uri('assets/'.($photos[$p->post_name]??'grau').'.webp');$description=wp_strip_all_tags(strip_shortcodes($p->post_content)); ?>
 <article class="product-card" data-product-id="<?php echo esc_attr($p->ID); ?>" data-product-title="<?php echo esc_attr($p->post_title); ?>" data-product-description="<?php echo esc_attr($description); ?>" data-product-image="<?php echo esc_url($photo); ?>">
 <button class="product-image-button" type="button" data-open-product aria-label="<?php echo esc_attr('Explorar '.$p->post_title); ?>"><img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($p->post_title.' — fotografia de referência'); ?>" loading="lazy" width="600" height="760"><span class="product-photo-label">EXPLORAR <span aria-hidden="true">↗︎</span></span></button>
 <div class="product-caption"><span class="collection-number"><?php echo esc_html(str_pad((string)($i+1),2,'0',STR_PAD_LEFT)); ?></span><h3><?php echo esc_html($p->post_title); ?></h3><p><?php echo esc_html($description); ?></p><a href="<?php echo esc_url(home_url('/agendamento/')); ?>" data-conversion="product-contact">Quero conhecer ↗︎</a></div></article>
 <?php }echo '</div></div>';return ob_get_clean();
});
add_shortcode('otica_footer_unidades',function(){ $out='<ul class="footer-stores">';foreach(otica_stores() as $s)$out.='<li><strong>'.esc_html($s->post_title).'</strong><br>'.esc_html(get_post_meta($s->ID,'_otica_endereco',true)).'</li>';return $out.'</ul>'; });
add_action('wp_footer',function(){echo '<a class="floating-contact" data-conversion="floating-whatsapp" href="'.esc_url(home_url('/agendamento/')).'" aria-label="Escolher unidade para contato pelo WhatsApp">Vamos conversar? <span aria-hidden="true">↗︎</span></a>';});
add_action('wp_head',function(){
 $items=[];foreach(otica_stores() as $s){$a=['@type'=>'Optician','name'=>$s->post_title,'address'=>get_post_meta($s->ID,'_otica_endereco',true),'url'=>get_permalink($s)];if(otica_phone($s->ID))$a['telephone']='+'.otica_phone($s->ID);$items[]=$a;}
 if($items)echo '<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@graph'=>$items],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';
 if(is_singular()){$desc=get_post_meta(get_queried_object_id(),'_otica_seo',true);if($desc)echo '<meta name="description" content="'.esc_attr($desc).'">';}
});
add_action('add_meta_boxes',function(){foreach(['page','post','produto_otica','unidade'] as $type)add_meta_box('otica-seo','Descrição para buscadores',function($post){wp_nonce_field('otica_seo','otica_seo_nonce');echo '<textarea name="otica_seo" rows="3" style="width:100%">'.esc_textarea(get_post_meta($post->ID,'_otica_seo',true)).'</textarea><p>O título do conteúdo é usado como título SEO. Use uma descrição objetiva, específica e sem promessas não comprovadas.</p>';},$type,'normal');});
add_action('save_post',function($id){if(isset($_POST['otica_seo_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['otica_seo_nonce'])),'otica_seo') && current_user_can('edit_post',$id) && !(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE))update_post_meta($id,'_otica_seo',sanitize_textarea_field(wp_unslash($_POST['otica_seo']??'')));});

add_filter('render_block_data',function($block){
 if(($block['blockName']??'')==='core/navigation-link' && isset($block['attrs']['url']) && strpos($block['attrs']['url'],'/')===0)$block['attrs']['url']=home_url($block['attrs']['url']);
 return $block;
});
add_filter('render_block',function($content){
 $content=str_replace('ASSET_URL',esc_url(get_theme_file_uri('assets')),$content);
 return preg_replace_callback('/href="\/(?!\/)([^"<>]*)"/',function($m){return 'href="'.esc_url(home_url('/'.$m[1])).'"';},$content);
});
add_shortcode('otica_relacionados',function(){
 $current=get_queried_object_id();$cats=wp_get_post_categories($current);$args=['post_type'=>'post','numberposts'=>3,'post__not_in'=>[$current]];if($cats)$args['category__in']=$cats;
 $posts=get_posts($args);if(!$posts)return '<p>Novas dicas serão publicadas em breve.</p>';
 $out='<div class="related-grid">';foreach($posts as $p)$out.='<article><h3><a href="'.esc_url(get_permalink($p)).'">'.esc_html($p->post_title).'</a></h3><p>'.esc_html(wp_trim_words(wp_strip_all_tags($p->post_content),25)).'</p></article>';return $out.'</div>';
});

add_action('admin_notices',function(){ $key='otica_phone_error_'.get_current_user_id();if(get_transient($key)){delete_transient($key);echo '<div class="notice notice-error"><p>WhatsApp não atualizado: informe 55 + DDD + número (12 ou 13 dígitos), ou deixe vazio. O valor anterior foi preservado.</p></div>';}});

add_shortcode('otica_identidade',function(){
 $name=get_bloginfo('name');$placeholder=!$name || strpos($name,'hostingersite.com')!==false || $name==='My Blog' || $name==='WordPress';
 if($placeholder)$name='Rede de óticas';
 return '<a class="brand-name" href="'.esc_url(home_url('/')).'">'.esc_html($name).'</a>'.($placeholder && current_user_can('manage_options')?'<span class="brand-pending">Nome comercial a personalizar</span>':'');
});
add_filter('body_class',function($classes){$classes[]='otica-impacto';return $classes;});
