<?php
/**
 * Title: Chamada final com alto contraste
 * Slug: otica-rede/chamada
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section closing-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section closing-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">SEU PRÓXIMO OLHAR COMEÇA AQUI</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">VAMOS ENCONTRAR<br><em>SEUS NOVOS ÓCULOS?</em></h2><!-- /wp:heading --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {} --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/nossas-lojas/">ENCONTRE SUA UNIDADE ↗︎</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:group --></div><!-- /wp:group -->