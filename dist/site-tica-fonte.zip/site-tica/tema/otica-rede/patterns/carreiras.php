<?php
/**
 * Title: Trabalhe conosco — WhatsApp e e-mail
 * Slug: otica-rede/carreiras
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section careers-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section careers-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">VENHA FAZER PARTE</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">SEU TALENTO PODE<br><em>FAZER PARTE DO TIME.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Quer trabalhar com a gente? Apresente sua experiência e envie seu currículo pelos canais de recrutamento.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_carreiras]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->