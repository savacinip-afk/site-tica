<?php
/**
 * Title: Coleções com fotografia e filtros
 * Slug: otica-rede/produtos
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section products-section", "anchor": "descubra", "layout": {"type": "default"}, "align": "full"} --><div id="descubra" class="wp-block-group alignfull section products-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">UM OLHAR, MUITAS POSSIBILIDADES</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">SEU ESTILO.<br><em>SEUS ÓCULOS.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Do essencial ao marcante. Descubra opções que combinam com você.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_produtos]<!-- /wp:shortcode --><!-- wp:paragraph {"className": "reference-note"} --><p class="reference-note">Fotografias de referência. Consulte os modelos disponíveis em sua unidade.</p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:group -->