<?php
/**
 * Title: Convênios — três imagens retangulares
 * Slug: otica-rede/convenios
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className":"section agreements-section","layout":{"type":"default"},"align":"full"} --><div class="wp-block-group alignfull section agreements-section"><!-- wp:group {"className":"section-inner","layout":{"type":"default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className":"section-heading","layout":{"type":"default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">CONVÊNIOS</p><!-- /wp:paragraph --><!-- wp:heading --><h2 class="wp-block-heading">PARCERIAS QUE<br><em>APROXIMAM.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className":"section-intro"} --><p class="section-intro">Conheça os convênios da nossa rede. Consulte as condições diretamente com a unidade.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_convenios]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->