<?php
/**
 * Title: Marcas parceiras — carrossel automático
 * Slug: otica-rede/marcas
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section brands-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section brands-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">CONEXÕES QUE FAZEM SENTIDO</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">MARCAS QUE<br><em>CAMINHAM COM A GENTE.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Um espaço para apresentar as marcas parceiras da nossa rede.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_marcas]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->