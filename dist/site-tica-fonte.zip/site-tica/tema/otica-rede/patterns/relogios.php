<?php
/**
 * Title: Relógios com cadastro no painel
 * Slug: otica-rede/relogios
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section watches-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section watches-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">CADA SEGUNDO, UMA ESCOLHA</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">O TEMPO PASSA.<br><em>O ESTILO FICA.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Conheça nossa seleção de relógios. Consulte modelos e disponibilidade diretamente com a unidade.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_relogios]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->