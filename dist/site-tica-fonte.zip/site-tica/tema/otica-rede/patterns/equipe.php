<?php
/**
 * Title: Quadro de funcionários administrável
 * Slug: otica-rede/equipe
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section team-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section team-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">NOSSO TIME</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">NOSSO MELHOR<br><em>É FEITO POR PESSOAS.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Conheça as pessoas que fazem parte da nossa equipe.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_equipe]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->