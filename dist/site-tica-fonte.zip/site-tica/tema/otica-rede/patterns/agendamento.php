<?php
/**
 * Title: Agendamento interativo em etapas
 * Slug: otica-rede/agendamento
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section appointment-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section appointment-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:shortcode -->[otica_agendamento]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->