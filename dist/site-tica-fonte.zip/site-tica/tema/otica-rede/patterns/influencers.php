<?php
/**
 * Title: Influencers — quatro espaços com estética social
 * Slug: otica-rede/influencers
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section influencers-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section influencers-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">NOSSA REDE TAMBÉM SE CONECTA</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">ESTILO QUE<br><em>INSPIRA E CONECTA.</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Conheça os perfis que fazem parte das nossas conexões.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_influencers]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->