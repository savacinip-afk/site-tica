<?php
/**
 * Title: Faixa de estilo em movimento
 * Slug: otica-rede/movimento
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "marquee-strip", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull marquee-strip"><!-- wp:paragraph {"className": "marquee-track"} --><p class="marquee-track">VER. VIVER. SE EXPRESSAR. <span aria-hidden="true">✦ VER. VIVER. SE EXPRESSAR. ✦</span></p><!-- /wp:paragraph --></div><!-- /wp:group -->