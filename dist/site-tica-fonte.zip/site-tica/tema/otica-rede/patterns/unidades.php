<?php
/**
 * Title: Lojas com filtro por cidade
 * Slug: otica-rede/unidades
 * Categories: otica
 * Inserter: yes
 */
?>
<!-- wp:group {"className": "section stores-section", "layout": {"type": "default"}, "align": "full"} --><div class="wp-block-group alignfull section stores-section"><!-- wp:group {"className": "section-inner", "layout": {"type": "default"}} --><div class="wp-block-group section-inner"><!-- wp:group {"className": "section-heading", "layout": {"type": "default"}} --><div class="wp-block-group section-heading"><!-- wp:paragraph {"className": "eyebrow"} --><p class="eyebrow">ESTAMOS PERTO DE VOCÊ</p><!-- /wp:paragraph --><!-- wp:heading {"level": 2} --><h2 class="wp-block-heading">A ÓTICA MAIS<br><em>PRÓXIMA DE VOCÊ!</em></h2><!-- /wp:heading --><!-- wp:paragraph {"className": "section-intro"} --><p class="section-intro">Estamos presentes em cinco endereços para cuidar da sua visão com conforto, qualidade e atendimento personalizado.</p><!-- /wp:paragraph --></div><!-- /wp:group --><!-- wp:shortcode -->[otica_unidades]<!-- /wp:shortcode --></div><!-- /wp:group --></div><!-- /wp:group -->