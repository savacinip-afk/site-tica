<?php
/** Conteúdos comerciais e comunidade. Sem dependências externas. */
if (!defined('ABSPATH')) exit;

add_action('init', function () {
    foreach ([
        'otica_relogio' => ['Relógios', 'Relógio', 'dashicons-clock'],
        'otica_marca' => ['Marcas parceiras', 'Marca parceira', 'dashicons-awards'],
        'otica_convenio' => ['Convênios', 'Convênio', 'dashicons-images-alt2'],
        'otica_influencer' => ['Influencers', 'Influencer', 'dashicons-camera'],
        'otica_pessoa' => ['Equipe', 'Funcionário', 'dashicons-groups'],
    ] as $type => $labels) {
        register_post_type($type, [
            'labels' => ['name' => $labels[0], 'singular_name' => $labels[1], 'add_new_item' => 'Adicionar ' . $labels[1]],
            'public' => false, 'show_ui' => true, 'show_in_rest' => true,
            'show_in_menu' => 'otica-conteudos', 'menu_icon' => $labels[2],
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'page-attributes'],
            'capability_type' => 'post', 'map_meta_cap' => true,
        ]);
    }
});

add_action('admin_menu', function () {
    add_menu_page('Conteúdos da rede', 'Conteúdos da rede', 'edit_posts', 'otica-conteudos', 'otica_community_admin', 'dashicons-store', 26);
    add_submenu_page('otica-conteudos', 'Trabalhe conosco', 'Trabalhe conosco', 'manage_options', 'otica-carreiras', 'otica_careers_admin');
});
function otica_community_admin() {
    if (!current_user_can('edit_posts')) return;
    echo '<div class="wrap"><h1>Conteúdos da rede</h1><p>Use os submenus para editar relógios, marcas parceiras, convênios, influencers e funcionários.</p><ul><li><strong>Fotografia ou logo:</strong> abra o cadastro e use Imagem destacada.</li><li><strong>Nome:</strong> edite o título. Não mantenha os nomes provisórios depois de cadastrar os materiais reais.</li><li><strong>Texto curto ou cargo:</strong> use o campo Resumo.</li><li><strong>Ordem:</strong> use o número em Atributos → Ordem (menor número aparece primeiro).</li><li><strong>Instagram:</strong> configure o link na caixa própria do influencer.</li><li><strong>Visibilidade:</strong> publique o cadastro para visitantes; rascunhos são exibidos apenas para editores autenticados. Registros na lixeira deixam de aparecer.</li></ul><p>Os cadastros iniciais são espaços reservados: 15 marcas, 3 convênios, 4 influencers, 6 funcionários e 3 relógios. Você pode adicionar, remover ou reordenar itens. Sem material cadastrado, a página mostra espaços claramente identificados, sem inventar marcas, pessoas ou contatos.</p><p>O envio de currículo é configurado em <strong>Trabalhe conosco</strong>. Nenhum currículo é recebido ou armazenado pelo tema: o visitante abre seu próprio WhatsApp ou aplicativo de e-mail e anexa o arquivo.</p></div>';
}

add_action('add_meta_boxes', function () {
    add_meta_box('otica-instagram', 'Perfil no Instagram', function ($post) {
        wp_nonce_field('otica_instagram', 'otica_instagram_nonce');
        echo '<p><label for="otica_instagram_url">Link completo do perfil (opcional)</label><input style="width:100%" type="url" id="otica_instagram_url" name="otica_instagram_url" placeholder="https://www.instagram.com/..." value="' . esc_attr(get_post_meta($post->ID, '_otica_instagram', true)) . '"></p><p>Cadastre somente um perfil real e autorizado. Sem link, o card não abre uma conta fictícia.</p>';
    }, 'otica_influencer', 'normal');
});
add_action('save_post_otica_influencer', function ($id) {
    if (!isset($_POST['otica_instagram_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['otica_instagram_nonce'])), 'otica_instagram') || !current_user_can('edit_post', $id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
    $raw = trim(sanitize_text_field(wp_unslash($_POST['otica_instagram_url'] ?? '')));
    $url = esc_url_raw($raw, ['https']);
    $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
    if ($raw && (!$url || !in_array($host, ['instagram.com', 'www.instagram.com'], true))) {
        set_transient('otica_social_error_' . get_current_user_id(), true, 60); return;
    }
    update_post_meta($id, '_otica_instagram', $url);
});
add_action('admin_notices', function () {
    $key = 'otica_social_error_' . get_current_user_id();
    if (get_transient($key)) { delete_transient($key); echo '<div class="notice notice-error"><p>O perfil não foi atualizado. Use um link HTTPS válido de instagram.com. O valor anterior foi preservado.</p></div>'; }
});

add_action('admin_init', function () {
    register_setting('otica_careers', 'otica_careers_phone', ['type' => 'string', 'default' => '', 'sanitize_callback' => function ($raw) {
        $value = preg_replace('/\D/', '', (string) $raw);
        if ($value && !preg_match('/^55[1-9][0-9]{9,10}$/', $value)) {
            add_settings_error('otica_careers', 'phone', 'WhatsApp não alterado: informe 55 + DDD + número ou deixe vazio.'); return get_option('otica_careers_phone', '');
        } return $value;
    }]);
    register_setting('otica_careers', 'otica_careers_email', ['type' => 'string', 'default' => '', 'sanitize_callback' => function ($raw) {
        $raw = trim((string) $raw); $value = sanitize_email($raw);
        if ($raw && (!$value || !is_email($value))) {
            add_settings_error('otica_careers', 'email', 'E-mail não alterado: informe um endereço válido ou deixe vazio.'); return get_option('otica_careers_email', '');
        } return $value;
    }]);
});
function otica_careers_admin() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Trabalhe conosco — recebimento de currículos</h1><p>Cadastre os contatos reais do recrutamento. Não são os números de agendamento das lojas. Os botões ficam indisponíveis enquanto os campos estiverem vazios.</p>';
    settings_errors('otica_careers'); echo '<form action="options.php" method="post">'; settings_fields('otica_careers');
    echo '<table class="form-table"><tr><th><label for="careers-phone">WhatsApp do recrutamento</label></th><td><input id="careers-phone" type="text" inputmode="numeric" name="otica_careers_phone" class="regular-text" value="' . esc_attr(get_option('otica_careers_phone', '')) . '"><p class="description">55 + DDD + número, somente dígitos. Deixe vazio para desativar.</p></td></tr><tr><th><label for="careers-email">E-mail para currículos</label></th><td><input id="careers-email" type="email" name="otica_careers_email" class="regular-text" value="' . esc_attr(get_option('otica_careers_email', '')) . '"><p class="description">Apenas um e-mail comercial real. Não é necessário configurar senha ou SMTP.</p></td></tr></table>';
    submit_button('Salvar contatos de recrutamento'); echo '</form><p>O candidato precisará anexar seu currículo no WhatsApp ou no programa de e-mail depois de abrir o canal. Revise a Política de Privacidade para informar a finalidade, os responsáveis e a retenção dos currículos antes de ativar o recebimento.</p></div>';
}

function otica_community_posts($type, $fallback) {
    $posts = get_posts(['post_type' => $type, 'numberposts' => -1, 'post_status' => current_user_can('edit_posts') ? ['publish', 'draft'] : ['publish'], 'orderby' => 'menu_order ID', 'order' => 'ASC']);
    return $posts ?: array_fill(0, $fallback, null);
}
function otica_community_excerpt($post, $fallback = '') {
    if (!$post) return $fallback;
    return $post->post_excerpt ? wp_strip_all_tags($post->post_excerpt) : $fallback;
}
function otica_social_camera() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.7" cy="6.5" r=".8" fill="currentColor" stroke="none"/></svg>';
}
function otica_person_placeholder() {
    return '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="50" cy="34" r="15"/><path d="M22 87v-8c0-37 56-37 56 0v8"/></svg>';
}

add_shortcode('otica_marcas', function () {
    $items = otica_community_posts('otica_marca', 15); $count = count($items); ob_start(); ?>
    <div class="brand-carousel" data-brand-carousel data-brand-count="<?php echo esc_attr($count); ?>" role="region" aria-roledescription="carrossel" aria-label="Marcas parceiras">
        <div class="brand-viewport" tabindex="0" aria-label="Logotipos. Use as setas do teclado para navegar."><div class="brands-track" role="list">
        <?php foreach ($items as $i => $post): $photo = $post && has_post_thumbnail($post); $title = $post ? $post->post_title : 'Marca ' . str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT); ?>
            <div class="brand-card<?php echo $photo ? '' : ' brand-placeholder'; ?>" role="listitem" data-brand-original>
                <?php if ($photo): echo get_the_post_thumbnail($post, 'medium', ['loading' => 'lazy', 'alt' => $title]); else: ?><span class="brand-slot-number"><?php echo esc_html(str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT)); ?></span><strong><?php echo esc_html($title); ?></strong><span>LOGOTIPO A CADASTRAR</span><?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div></div>
        <div class="brand-controls"><p class="brand-caption">Marcas e logotipos sujeitos a cadastro e confirmação.</p><div class="brand-control-buttons"><span class="brand-position" aria-hidden="true">01 / <?php echo esc_html(str_pad((string) $count, 2, '0', STR_PAD_LEFT)); ?></span><button type="button" class="brand-nav" data-brand-prev aria-label="Mostrar marcas anteriores">←</button><button type="button" class="brand-nav brand-pause" data-brand-pause aria-label="Pausar movimento automático" aria-pressed="false">Ⅱ</button><button type="button" class="brand-nav" data-brand-next aria-label="Mostrar próximas marcas">→</button></div></div>
        <p class="screen-reader-text brand-announcement" aria-live="polite"></p>
    </div>
    <?php return ob_get_clean();
});

add_shortcode('otica_relogios', function () {
    $items = otica_community_posts('otica_relogio', 3); ob_start(); echo '<div class="watches-grid">';
    foreach ($items as $i => $post) {
        $photo = $post && has_post_thumbnail($post); $title = $post ? $post->post_title : 'Relógios — seleção ' . ($i + 1);
        echo '<article class="watch-card"><div class="watch-image">';
        if ($photo) echo get_the_post_thumbnail($post, 'large', ['loading' => 'lazy']);
        else echo '<img src="' . esc_url(get_theme_file_uri('assets/relogio-referencia.svg')) . '" alt="Ilustração provisória de relógio, não representa um modelo do estoque" loading="lazy" width="600" height="680"><span class="watch-image-note">FOTOGRAFIA A CADASTRAR</span>';
        echo '</div><div class="watch-copy"><span class="eyebrow">TEMPO & ESTILO</span><h3>' . esc_html($title) . '</h3><p>' . esc_html(otica_community_excerpt($post, 'Detalhes e fotografia dos modelos a cadastrar.')) . '</p><a href="' . esc_url(home_url('/nossas-lojas/')) . '" data-conversion="watch-contact">CONSULTAR NA UNIDADE ↗︎</a></div></article>';
    } echo '</div>'; return ob_get_clean();
});

add_shortcode('otica_influencers', function () {
    $items = otica_community_posts('otica_influencer', 4); ob_start(); echo '<div class="influencers-grid">';
    foreach ($items as $i => $post) {
        $photo = $post && has_post_thumbnail($post); $title = $post ? $post->post_title : 'Influencer ' . str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT);
        $url = $post ? get_post_meta($post->ID, '_otica_instagram', true) : '';
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if (!in_array($host, ['instagram.com', 'www.instagram.com'], true) || strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https') $url = '';
        echo '<article class="influencer-card"><div class="influencer-top"><span class="social-avatar">' . otica_social_camera() . '</span><span>' . esc_html($title) . '</span><span class="social-dots" aria-hidden="true">•••</span></div><div class="influencer-image">';
        if ($photo) echo get_the_post_thumbnail($post, 'large', ['loading' => 'lazy']);
        else echo '<div class="person-placeholder">' . otica_person_placeholder() . '<span>FOTO A CADASTRAR</span></div>';
        echo '<span class="influencer-photo-index">' . esc_html(str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT)) . '</span></div><div class="influencer-caption"><span class="social-heart" aria-hidden="true">♡</span><strong>' . esc_html($title) . '</strong><p>' . esc_html(otica_community_excerpt($post, 'Espaço reservado para um perfil parceiro.')) . '</p>';
        if ($url) echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer" data-conversion="influencer-instagram">VER NO INSTAGRAM ↗︎</a>';
        else echo '<span class="pending-social">PERFIL A CADASTRAR</span>';
        echo '</div></article>';
    } echo '</div>'; return ob_get_clean();
});

add_shortcode('otica_equipe', function () {
    $items = otica_community_posts('otica_pessoa', 6); ob_start(); echo '<div class="team-grid">';
    foreach ($items as $i => $post) {
        $photo = $post && has_post_thumbnail($post); $title = $post ? $post->post_title : 'Profissional ' . str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT);
        echo '<article class="team-card"><div class="team-photo">';
        if ($photo) echo get_the_post_thumbnail($post, 'large', ['loading' => 'lazy']);
        else echo '<div class="person-placeholder">' . otica_person_placeholder() . '<span>FOTO A CADASTRAR</span></div>';
        echo '</div><h3>' . esc_html($title) . '</h3><p>' . esc_html(otica_community_excerpt($post, 'Nome e função a cadastrar.')) . '</p></article>';
    } echo '</div>'; return ob_get_clean();
});

add_shortcode('otica_carreiras', function () {
    $phone = get_option('otica_careers_phone', ''); if (!preg_match('/^55[1-9][0-9]{9,10}$/', $phone)) $phone = '';
    $email = get_option('otica_careers_email', ''); if (!is_email($email)) $email = '';
    $out = '<div class="careers-actions">';
    if ($phone) $out .= '<a class="button" data-conversion="careers-whatsapp" href="' . esc_url('https://wa.me/' . $phone . '?text=' . rawurlencode('Olá! Gostaria de fazer parte do time e enviar meu currículo.')) . '" target="_blank" rel="noopener noreferrer">ENVIAR CURRÍCULO PELO WHATSAPP ↗︎</a>';
    else $out .= '<span class="career-unavailable" aria-disabled="true">WHATSAPP DE RECRUTAMENTO A CADASTRAR</span>';
    if ($email) $out .= '<a class="button career-email" data-conversion="careers-email" href="' . esc_url('mailto:' . $email . '?subject=' . rawurlencode('Candidatura — trabalhe conosco') . '&body=' . rawurlencode('Olá! Gostaria de fazer parte do time. Segue meu currículo em anexo.')) . '">ENVIAR CURRÍCULO POR E-MAIL ↗︎</a>';
    else $out .= '<span class="career-unavailable" aria-disabled="true">E-MAIL DE RECRUTAMENTO A CADASTRAR</span>';
    return $out . '</div><p class="career-note">Depois de abrir o WhatsApp ou seu aplicativo de e-mail, anexe o currículo antes de enviar. Não há confirmação automática de vaga ou contratação. Envie apenas os dados necessários à candidatura. <a href="' . esc_url(home_url('/politica-de-privacidade/')) . '">Política de Privacidade</a>.</p>';
});

function otica_seed_community() {
    if (!current_user_can('manage_options')) return;
    foreach ([
        'otica_marca' => [15, 'Marca', 'Cadastre o nome e a imagem do logotipo.'],
        'otica_convenio' => [3, 'Convênio', 'Informações do convênio a cadastrar.'],
        'otica_influencer' => [4, 'Influencer', 'Espaço reservado para um perfil parceiro.'],
        'otica_pessoa' => [6, 'Profissional', 'Nome e função a cadastrar.'],
        'otica_relogio' => [3, 'Relógios — seleção', 'Detalhes e fotografia dos modelos a cadastrar.'],
    ] as $type => $config) {
        // Se o responsável já possui cadastros desse tipo, não acrescente placeholders.
        if (get_posts(['post_type' => $type, 'post_status' => ['publish', 'draft', 'pending', 'private', 'future', 'trash'], 'numberposts' => 1])) continue;
        for ($i = 1; $i <= $config[0]; $i++) wp_insert_post(['post_type' => $type, 'post_status' => 'draft', 'post_title' => $config[1] . ' ' . str_pad((string) $i, 2, '0', STR_PAD_LEFT), 'post_name' => $type . '-espaco-' . $i, 'post_excerpt' => $config[2], 'menu_order' => $i]);
    }
}

function otica_expand_patterns($body) {
    return preg_replace_callback('/PATTERN:([a-z-]+)\n/', function ($match) {
        $file = __DIR__ . '/patterns/' . $match[1] . '.php';
        if (!is_file($file)) return '';
        ob_start(); include $file; return ob_get_clean();
    }, $body);
}
function otica_insert_section($body, $class, $new, $before = false) {
    $blocks = parse_blocks($body); $addition = parse_blocks($new);
    foreach ($blocks as $i => $block) {
        $classes = preg_split('/\s+/', $block['attrs']['className'] ?? '');
        if (in_array($class, $classes, true)) { array_splice($blocks, $i + ($before ? 0 : 1), 0, $addition); return serialize_blocks($blocks); }
    }
    return $body . $new;
}
function otica_create_expansion_v21() {
    if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Permissão insuficiente.');
    otica_seed_community();
    $ids = get_option('otica_expansion_v21', []); if (!is_array($ids)) $ids = [];
    $data = json_decode(file_get_contents(__DIR__ . '/content.json'), true);
    foreach (['home', 'about'] as $kind) {
        if (!empty($ids[$kind]) && get_post_type($ids[$kind]) === 'page' && get_post_status($ids[$kind]) !== 'trash') continue;
        $slug = $kind === 'home' ? 'inicio-visual-21' : 'sobre-nos-equipe';
        $existing = get_page_by_path($slug);
        if ($existing) { $ids[$kind] = $existing->ID; continue; }
        if ($kind === 'home') {
            $source = get_post((int) get_option('page_on_front'));
            if (!$source || $source->post_type !== 'page' || strpos($source->post_content, 'hero-v2') === false) $source = get_page_by_path('inicio-visual-2');
            $body = $source && strpos($source->post_content, 'hero-v2') !== false ? $source->post_content : otica_expand_patterns($data['pages']['inicio'][1]);
            if (strpos($body, '[otica_relogios]') === false) $body = otica_insert_section($body, 'products-section', otica_expand_patterns("PATTERN:relogios\n"));
            if (strpos($body, '[otica_marcas]') === false) $body = otica_insert_section($body, 'watches-section', otica_expand_patterns("PATTERN:marcas\n"));
            if (strpos($body, '[otica_influencers]') === false) $body = otica_insert_section($body, 'benefits-section', otica_expand_patterns("PATTERN:influencers\n"));
            if (strpos($body, 'about-preview-section') === false) $body = otica_insert_section($body, 'closing-section', otica_expand_patterns("PATTERN:sobre-previa\n"), true);
            $title = 'Início — relógios, marcas e novidades'; $template = 'vitrine';
        } else {
            $source = get_page_by_path('sobre-nos');
            $body = $source ? $source->post_content : otica_expand_patterns($data['pages']['sobre-nos'][1]);
            if (strpos($body, '[otica_equipe]') === false) $body .= otica_expand_patterns("PATTERN:equipe\n");
            if (strpos($body, '[otica_carreiras]') === false) $body .= otica_expand_patterns("PATTERN:carreiras\n");
            $title = 'Sobre nós'; $template = 'institucional';
        }
        $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'draft', 'post_name' => $slug, 'post_title' => $title, 'post_content' => $body], true);
        if (is_wp_error($id)) return $id;
        update_post_meta($id, '_wp_page_template', $template);
        if ($source) update_post_meta($id, '_otica_source_page', $source->ID);
        $ids[$kind] = $id;
        update_option('otica_expansion_v21', $ids, false);
    }
    return $ids;
}
// As prévias da nova home apontam à nova página institucional. Para visitantes,
// o destino só muda depois de o responsável publicar a nova página Sobre nós.
add_filter('render_block', function ($html) {
    $ids = get_option('otica_expansion_v21', []); $id = is_array($ids) ? (int) ($ids['about'] ?? 0) : 0;
    if (!$id || get_post_type($id) !== 'page') return $html;
    $published = get_post_status($id) === 'publish';
    $preview = current_user_can('edit_post', $id) && in_array(get_queried_object_id(), [(int) ($ids['home'] ?? 0), (int) get_option('otica_final_v22', 0)], true);
    if (!$published && !$preview) return $html;
    $url = $published ? get_permalink($id) : get_preview_post_link($id);
    return str_replace('href="' . esc_url(home_url('/sobre-nos/')) . '"', 'href="' . esc_url($url) . '"', $html);
}, 12);


add_shortcode('otica_convenios', function () {
    $items = otica_community_posts('otica_convenio', 3); ob_start(); echo '<div class="agreements-grid">';
    foreach ($items as $i => $post) {
        $photo = $post && has_post_thumbnail($post); $title = $post ? $post->post_title : 'Convênio ' . str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT);
        echo '<article class="agreement-card"><div class="agreement-image">';
        if ($photo) echo get_the_post_thumbnail($post, 'large', ['loading' => 'lazy', 'alt' => $title]);
        else echo '<div class="agreement-placeholder"><svg viewBox="0 0 60 44" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true"><rect x="2" y="2" width="56" height="40" rx="4"/><circle cx="18" cy="15" r="4"/><path d="m4 35 15-13 10 8 12-15 15 20"/></svg><span>IMAGEM DO CONVÊNIO A CADASTRAR</span></div>';
        echo '</div><div class="agreement-copy"><h3>' . esc_html($title) . '</h3><p>' . esc_html(otica_community_excerpt($post, 'Informações do convênio a cadastrar.')) . '</p></div></article>';
    } echo '</div>'; return ob_get_clean();
});

function otica_create_final_v22() {
    if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Permissão insuficiente.');
    otica_seed_community();
    $existing = get_page_by_path('inicio-final-22'); if ($existing) return $existing->ID;
    $expansion = otica_create_expansion_v21(); if (is_wp_error($expansion)) return $expansion;
    $source = get_post((int) get_option('page_on_front'));
    if (!$source || strpos($source->post_content, '[otica_influencers]') === false) $source = get_post($expansion['home']);
    $body = $source->post_content;
    if (strpos($body, '[otica_convenios]') === false) $body = otica_insert_section($body, 'brands-section', otica_expand_patterns("PATTERN:convenios\n"));
    $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'draft', 'post_name' => 'inicio-final-22', 'post_title' => 'Início — versão final com convênios', 'post_content' => $body], true);
    if (is_wp_error($id)) return $id;
    update_post_meta($id, '_wp_page_template', 'vitrine'); update_post_meta($id, '_otica_source_page', $source->ID);
    update_option('otica_final_v22', $id, false); return $id;
}
