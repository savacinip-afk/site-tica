#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Somente a demonstração local. A Hostinger usa o instalador oficial de plugins.
if [ -s .runtime/WordPress-6.8/wp-content/plugins/elementor/elementor.php ]; then
  echo 'Elementor já disponível na demonstração local.'
  exit 0
fi
mkdir -p .cache .runtime/WordPress-6.8/wp-content/plugins
curl --fail --location --retry 2 https://github.com/elementor/elementor/releases/download/4.3.5/elementor-4.3.5.zip --output .cache/elementor-4.3.5.zip
python3 - <<'PY'
from zipfile import ZipFile
with ZipFile('.cache/elementor-4.3.5.zip') as archive:
    if archive.testzip(): raise SystemExit('Arquivo do Elementor corrompido')
    if 'elementor/elementor.php' not in archive.namelist(): raise SystemExit('Pacote de plugin inválido')
    archive.extractall('.runtime/WordPress-6.8/wp-content/plugins')
PY
