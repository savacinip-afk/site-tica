#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Apenas demonstração local. Não usar este servidor WASM para produção.
exec ./node_modules/.bin/wp-playground-cli server --wp 6.8 --php 8.3 \
 --mount-before-install "$PWD/.runtime/WordPress-6.8:/wordpress" \
 --wordpress-install-mode install-from-existing-files-if-needed \
 --mount "$(dirname "$PWD")/tema/otica-rede:/wordpress/wp-content/themes/otica-rede" \
 --blueprint "$PWD/blueprint.json" --port 9400 --workers 6 --define WP_MEMORY_LIMIT 256M --define WP_MAX_MEMORY_LIMIT 512M
