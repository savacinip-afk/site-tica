// Chromium pode repetir regiões em capturas únicas acima do limite de rasterização.
// Captura faixas reais da viewport e as une sem modificar a página.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');const {execFileSync}=require('node:child_process');
module.exports=async function captureFullPage(page,destination){
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'otica-tiles-'));const initial=await page.evaluate(()=>({x:scrollX,y:scrollY,reduced:matchMedia('(prefers-reduced-motion:reduce)').matches}));
 try{
  await page.emulateMedia({reducedMotion:'reduce'});await page.evaluate(()=>document.fonts.ready);
  for(const image of await page.locator('main img').all()){await image.scrollIntoViewIfNeeded();await image.evaluate(el=>el.decode().catch(()=>{}));}
  await page.evaluate(()=>window.scrollTo({top:0,left:0,behavior:'instant'}));
  const size=await page.evaluate(()=>({width:innerWidth,height:document.documentElement.scrollHeight,viewport:innerHeight}));
  const tiles=[];let target=0;
  while(target<size.height){
   await page.evaluate(y=>window.scrollTo({top:y,left:0,behavior:'instant'}),Math.min(target,Math.max(0,size.height-size.viewport)));
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
   const actual=await page.evaluate(()=>scrollY),crop=Math.max(0,Math.round(target-actual)),height=Math.min(size.viewport-crop,size.height-target);
   if(height<=0)throw new Error('Falha ao avançar na captura da página.');
   const file=path.join(temp,String(tiles.length)+'.png');await page.screenshot({path:file,scale:'css',animations:'disabled',style:target===0?'':'.wp-site-blocks>header.wp-block-template-part,.floating-contact,.scroll-progress{visibility:hidden!important}'});
   tiles.push({file,y:target,crop,height});target+=height;
  }
  const manifest=path.join(temp,'manifest.json');fs.writeFileSync(manifest,JSON.stringify({...size,tiles}));execFileSync('python3',[path.join(__dirname,'stitch-capture.py'),manifest,path.resolve(destination)],{stdio:'pipe'});
 }finally{
  await page.emulateMedia({reducedMotion:initial.reduced?'reduce':'no-preference'});await page.evaluate(position=>window.scrollTo({left:position.x,top:position.y,behavior:'instant'}),initial);fs.rmSync(temp,{recursive:true,force:true});
 }
};
