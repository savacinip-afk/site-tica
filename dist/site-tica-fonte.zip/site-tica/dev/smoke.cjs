const { chromium: playwright }=require('@playwright/test');
const chromium=require('@sparticuz/chromium').default;
const assert=require('node:assert/strict');
(async()=>{
const browser=await playwright.launch({executablePath:await chromium.executablePath(),args:chromium.args,headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
for(const path of ['/','/nossas-lojas/','/produtos/','/sobre-nos/','/dicas-sobre-visao/','/agendamento/','/politica-de-privacidade/']){const res=await page.goto('http://127.0.0.1:9400'+path);assert.equal(res.status(),200,path);assert.equal(await page.locator('main').count(),1);assert.ok(!(await page.textContent('body')).includes('Fatal error'));}
await page.goto('http://127.0.0.1:9400/');assert.equal(await page.locator('.store-card').count(),5);
await page.screenshot({path:'/workspace/site-tica/dist/inicio-desktop.png',fullPage:true});
await page.locator('#next-step').click();assert.match(await page.locator('#form-error').innerText(),/obrigatórios/);
await page.locator('[name=exam]').first().check();await page.locator('#next-step').click();await page.locator('[name=store]').nth(3).check();await page.locator('#next-step').click();
await page.locator('[name=customer]').fill('Ana de Teste');await page.locator('[name=phone]').fill('123');await page.locator('[name=period]').selectOption('Tarde');await page.locator('[name=consent]').check();await page.locator('#next-step').click();assert.match(await page.locator('#form-error').innerText(),/DDD/);
await page.locator('[name=phone]').fill('19999999999');await page.locator('#next-step').click();assert.ok(await page.locator('#missing-phone').isVisible());assert.ok(await page.locator('#whatsapp-submit').isHidden());
// Test-only destination is injected into DOM; never persisted as a store phone and never contacted.
await page.locator('#prev-step').click();await page.locator('#prev-step').click();await page.locator('[name=store]:checked').evaluate(el=>el.dataset.phone='5511999999999');await page.locator('#next-step').click();await page.locator('#next-step').click();
const target=new URL(await page.locator('#whatsapp-submit').getAttribute('href'));assert.equal(target.hostname,'wa.me');assert.match(target.searchParams.get('text'),/Ana de Teste/);assert.match(target.searchParams.get('text'),/Pirassununga/);assert.match(target.searchParams.get('text'),/Último exame/);
const storeId=await page.locator('[name=store]:checked').inputValue();await page.goto('http://127.0.0.1:9400/agendamento/?otica_unidade='+storeId);assert.equal(await page.locator('[name=store]:checked').inputValue(),storeId);
await page.goto('http://127.0.0.1:9400/nossas-lojas/');assert.equal(await page.locator('iframe').count(),0);await page.route('https://www.google.com/**',r=>r.abort());await page.locator('.load-map').first().click();assert.equal(await page.locator('iframe').count(),1);
await page.setViewportSize({width:390,height:844});await page.goto('http://127.0.0.1:9400/');assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'/workspace/site-tica/dist/inicio-mobile.png',fullPage:true});
const menu=page.locator('.wp-block-navigation__responsive-container-open');await menu.click();await page.locator('.wp-block-navigation__responsive-container.is-menu-open').waitFor({state:'visible'});await page.keyboard.press('Escape');
assert.deepEqual(errors,[]);console.log('PASS: 7 páginas, 5 unidades, validação, seleção persistente, WhatsApp codificado/bloqueado, mapa sob demanda, mobile e menu.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
