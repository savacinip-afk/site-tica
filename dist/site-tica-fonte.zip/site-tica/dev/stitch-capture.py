"""Une faixas de captura reais. Requer Pillow apenas no ambiente de desenvolvimento."""
import json,sys
from pathlib import Path
from PIL import Image
manifest=json.loads(Path(sys.argv[1]).read_text())
canvas=Image.new('RGB',(manifest['width'],manifest['height']),'white')
next_y=0
for tile in manifest['tiles']:
    assert tile['y']==next_y
    with Image.open(tile['file']) as frame:
        assert frame.width==manifest['width']
        region=frame.crop((0,tile['crop'],manifest['width'],tile['crop']+tile['height']))
        canvas.paste(region,(0,tile['y']))
    next_y+=tile['height']
assert next_y==manifest['height']
canvas.save(sys.argv[2])
