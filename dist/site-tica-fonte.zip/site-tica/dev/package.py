from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
source=root/'tema'/'otica-rede'
(root/'dist').mkdir(exist_ok=True)
with ZipFile(root/'dist'/'otica-rede.zip','w',ZIP_DEFLATED) as archive:
    for path in sorted(source.rglob('*')):
        if path.is_file(): archive.write(path,path.relative_to(source.parent))
with ZipFile(root/'dist'/'otica-rede.zip') as archive:
    assert archive.testzip() is None
    assert 'otica-rede/style.css' in archive.namelist()
print('ZIP instalável gerado e verificado.')
