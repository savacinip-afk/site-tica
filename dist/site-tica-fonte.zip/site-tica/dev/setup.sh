#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
npm ci --no-audit --no-fund --cache /tmp/otica-npm-cache
mkdir -p .cache
if [ ! -s .cache/wordpress-6.8.zip ]; then
  curl --fail --location --retry 2 https://codeload.github.com/WordPress/WordPress/zip/refs/tags/6.8 --output .cache/wordpress-6.8.zip
fi
python3 - <<'PY'
import zipfile
from pathlib import Path
z=zipfile.ZipFile('.cache/wordpress-6.8.zip')
if z.testzip(): raise SystemExit('Arquivo WordPress corrompido')
if not Path('.runtime/WordPress-6.8/wp-includes/version.php').exists(): z.extractall('.runtime')
PY

# Elementor gratuito, usado pelas novas páginas de teste.
bash setup-elementor.sh
